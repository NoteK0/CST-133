//-----------------------------------------------------------------------------
//Exercise 5 Grading Block
//Name: Chad Cole
//Grade:
//General Comments:
//  
//  
//  
//  
//Standard Requirements
//  Requirements met as specified in the course and
//    summarized in the Programming Style Requirements Document
//  Which includes but not limited to:
//    Program Creation
//    Documentation
//    File Requirements
//    Constants
//    Variables 
//    Code
//
//Comments:
//  
//Points Lost -------------------------------------------------------------> 
//
//General Function Specs:
//  Functions prototypes correctly placed
//  Functions correctly named following course specs
//  Function calls appropriately placed and used in program
//  Function definitions correctly placed
//  Documentation above EACH function following course specs
//  Functions prototypes and definitions appear in the
//   ORDER listed in the assignment document in the correct location
//  Functions blocked appropriately
//Points will be deducted if necessary in the individual functions
//
//Program Specifications
//  Constants created for 
//    college name
//    student name 
//    course and exercise heading
//    screen width
//    character array size
//    counting array size
//    
//  Heading for the exercise output to the screen & output file 
//  Output file opened
//
//Comments:
//  
//Points Lost -------------------------------------------------------------> 
//
//Array Declarations
//  two character arrays of length 500
//  two int arrays of length 26
//  variables named as specified
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//Output file
//  Correct output file - Ex5Out.txt opened
//  Message displayed on screen stating name of output file
//
//Comment:
//
//Points Lost -------------------------------------------------------------> 
//
//Functions -------------------------------------------------------------------
//1.OutputDivider
//  Logical file name, the char, and the number of chs passed into the function
//
//Comment:
//  
//2.OpenInputFile
//  Prompts user until correct file name is entered
//  do while loop USED
//  error message printed if invalid file name is entered
//  successful opening message with file name displayed on screen
//
//Comment:
//
//3.OutputHeading
//  Centered heading output within the length of divider
//  Heading elements are defined as constants
//
//Comment:
//          
//Points Lost -------------------------------------------------------------> 
//
//4.FillChArray
//  File, char array, and length (tag field) in parameter list
//  Tag field set
//  Called twice once for data in each input file
//  Primer and changer used
//
//Comment:
//          
//Points Lost -------------------------------------------------------------> 
//
//5.InitializeIntArray
//  int array and length in parameter list
//  for loop used
//  Initializes each position in the array
//  Initializes one array, called twice
//
//Comment:
//          
//Points Lost -------------------------------------------------------------> 
//
//6.CountAlphabetCharacters
//  char array, length, and int array in parameter list
//  for loop used
//  No nested if or switch - ASCII value of ch used for position
//  toupper() function used to reduce testing
//  Counts set correctly
//
//Comment:
//            
//Points Lost -------------------------------------------------------------> 
//
//7.CalculateTotal
//  int array and length in parameter list
//  Single return function; returns total number of alphabetic characters 
//    in the array
//  for loop used
//  Called twice, once for each int array
//
//Comment:
//            
//Points Lost -------------------------------------------------------------> 
//
//8.CompareChArrays
//  two char arrays and two lengths in parameter list
//  Single return function returns the count where the chars
//    match in the same positions in both char arrays
//  uses length shorter array to control the loop
//  for loop used
//
//Comment:
//          
//Points Lost -------------------------------------------------------------> 
//
//Functions - Output-----------------------------------------------------------
//Output Functions - all to output file
//9. OutputChArray
//   Output each char in array
//   Starts with Line Number label 
//     and increments Number for each line
//   Next line after return key is printed
//
//10.OutputCountArray
//   Output label identifying the array
//   Outputs 13 letters of alphabet in formatted columns
//   Output counts under each alphabet heading 
//     in formatted columns under the letter headings
//
//11.OutputTotal
//   Output the total of the int array with a label
//
//12.OutputCompareCount
//   Outputs the two array names and the comparison count
//
//Comment:
//            
//Points Lost -------------------------------------------------------------> 
//
//13.Bonus - EncryptMessage
//  Message displayed above this output 
//  char up cased if letter of alphabet
//  Encrypted from the LAST character to the FIRST char
//  ASCII value used to calculate new char
//  New char of letter output to the output file
//  return key output but not encrypted
//
//Comment:
//            
//Points GAINED -----------------------------------------------------------> 
//  
//Efficient testing used for this solution
//Total Possible Lab Grade ------------------------------------------------> 200
//Total Points Lost ------------------------------------------------------->   
//Total Bonus Points GAINED ----------------------------------------------->   
//Actual Lab Grade --------------------------------------------------------> 
//-----------------------------------------------------------------------------
//Programmer's Name: Chad Cole
//Program:  Exercise 5
//Program Flow (IPO):
// Prompt the user to enter the name of the first input file
//		If it is wrong, ask the user to try again
// Prompt the user to enter the name of the second input file
//		If it is wrong, ask the user to try again
// Output a heading to the screen
// Open textFile1.txt and read in the data character by character, storing
// it in charRead1
// Open textFile2.txt and read in the data character by character, storing
// it in charRead2
// Initialize countChArray1 and 2 to zero for every element
// Count the number of each letter in the alphabet in charRead1 and charRead2,
// increment the zeroth element for letter A, etc.
// Calculate the total characters in both files
// Compare charRead1 and charRead2, and increment sameCounter if they have the
// same character in the same position
// Output the readChar arrays by lines 
// Output the coutChArrays
// Output the total characters between the files
// Output the instances where the character positions match up between text files
// Take from the last to the first character of an array, convert it to integer
// form, subtract 10 from it, and convert it back to a character. Output it.
//-----------------------------------------------------------------------------
#include <iostream> //Include input output stream


#include <fstream> //Include file stream


#include <iomanip> //Include input output manipulation


#include <string> //Include strings


using namespace std; //Use namespace

//Set constants

const string COLLEGE = "SUNY Broome Community College"; //Constants for Problem 1
const string CST_PROGRAMMER = "Chad Cole";
const string CLASS_AND_LAB = "CST 133 - Exercise 5";
const int WIDTH = 120;
const int MAX_CHARACTERS = 500; // Character limit for the file
const int MAX_LETTERS = 26; // Max letters limits array LCV to only the alphabet
const char divider = '-';

void OutputDivider(ofstream& fout); //Functions for Problem 1
void OpenInputFile(ofstream& fout, ifstream& fin, string inputFile1, string inputFile2);
void OutputHeading(ofstream& fout);
void FillChArray(ifstream& fin, char charRead1[], int& numberOfCharsF1);
void InitializeIntArray(int countChArray1[], int& numberOfInts1);
void CountAlphabetCharacters(ofstream& fout, int countChArray1[], char charRead1[], int& numberOfCharsF1);
void CalculateTotal(int countChArray1[], int numberOfCharsF1, int& totalCharacters1);
void CompareChArrays(char charRead1[], char charRead2[], int numberOfCharsF1, int numberOfCharsF2, int& sameCounter);
void OutputChArray(ofstream& fout, char charRead1[], char readChar, int N, int temp, string whichArray1, int numberOfCharsF1);
void OutputCountArray(ofstream& fout, int countChArray1[], string whichArray2);
void OutputTotal(ofstream& fout, int totalCharacters1, string whichArray3);
void OutputCompareCount(ofstream& fout, int &sameCounter, string whichArray4, string whichArray5);
void EncryptMessage(ofstream& fout, char charRead1[], int numberOfCharsF1);
int main(void) {
	int stringLength1; //Variables for Problem 1
	int stringLength2;
	int stringLength3;
	int numberOfChars = 0;
	int numberOfCharsF1 = 0; // Two tag fields for two arrays
	int numberOfCharsF2 = 0;
	char readChar = 0;
	int N = 0;
	int index = 0;
	int temp = 0;
	char charRead1[MAX_CHARACTERS];
	char charRead2[MAX_CHARACTERS];
	int countChArray1[MAX_LETTERS];
	int countChArray2[MAX_LETTERS];
	int numberOfInts1; // Two tag fields for two arrays
	int numberOfInts2;
	int totalCharacters1 = 0;
	int totalCharacters2 = 0;
	int sameCounter = 0;
	

	string inputFile1;
	string inputFile2;
	string whichArray1;
	string whichArray2;
	string whichArray3;
	string whichArray4;
	string whichArray5;

	ifstream fin;
	ofstream fout;

	stringLength1 = static_cast<int>(COLLEGE.length()); //Static cast string length to college length and so forth
	stringLength2 = static_cast<int>(CST_PROGRAMMER.length());
	stringLength3 = static_cast<int>(CLASS_AND_LAB.length());

	fout.open("Ex5Out.txt"); // Open the output file

	OutputHeading(fout);
	OutputHeading((ofstream&)cout);
	OpenInputFile(fout, fin, inputFile1, inputFile2);
	FillChArray(fin, charRead1, numberOfCharsF1);
	fin.close();
	fin.open("textFile2.txt");
	FillChArray(fin, charRead2, numberOfCharsF2);
	fin.close();
	InitializeIntArray(countChArray1, numberOfInts1);
	InitializeIntArray(countChArray2, numberOfInts2); //You can substitute arrays you call in the actual parameter as long as they're the same data type
	CountAlphabetCharacters(fout, countChArray1, charRead1, numberOfCharsF1);
	CountAlphabetCharacters(fout, countChArray2, charRead2, numberOfCharsF2);
	CalculateTotal(countChArray1, numberOfCharsF1, totalCharacters1);
	CalculateTotal(countChArray2, numberOfCharsF2, totalCharacters2);
	CompareChArrays(charRead1, charRead2, numberOfCharsF1, numberOfCharsF2, sameCounter);
	OutputChArray(fout, charRead1, readChar, N, temp, "charRead1", numberOfCharsF1);
	OutputChArray(fout, charRead2, readChar, N, temp, "charRead2", numberOfCharsF2);
	OutputCountArray(fout, countChArray1, "countChArray1");
	OutputCountArray(fout, countChArray2, "countChArray2");
	OutputTotal(fout, totalCharacters1, "charRead1");
	OutputTotal(fout, totalCharacters2, "charRead2");
	OutputCompareCount(fout, sameCounter, "countChArray1", "countChArray2");
	EncryptMessage(fout, charRead1, numberOfCharsF1);
	EncryptMessage(fout, charRead2, numberOfCharsF2);


	return 0; // If you see this again hi Ms. Sedelmeyer
}
//---------------------------------------------------------------------
//Function #1
//OutputDivider - This function prints a divider to the output file.            
//---------------------------------------------------------------------
void OutputDivider(ofstream& fout)
{
	fout << setfill(divider) << setw(WIDTH + 1) << ' ' << setfill(' ') << endl; //Sets a divider as a callable function


}
//---------------------------------------------------------------------
//Function #2
//OpenInputFile - This function prompts the user for the name of the
//				  input file and continues to ask the user for the name
//				  of the input file until a valid input file name is
//				  entered.
//---------------------------------------------------------------------
void OpenInputFile(ofstream& fout, ifstream& fin, string inputFile1, string inputFile2)
{
	cout << "The output file, Ex5Out.txt, contains the results from the run of the program"
		<< endl;
	cout << "Enter the name of the first input file: "; // User must enter the name of the first text file
	cin >> inputFile1;
	while (inputFile1 != "textFile1.txt") // If the user doesn't enter "textFile1.txt"...
	{
		OutputDivider(static_cast<ofstream&>(cout));
		cout << "File does not exist, try again." << endl;  // Tell them the file doesn't exist
		cout << "Enter the name of the first input file: "; // and prompt them to enter it again
		cin >> inputFile1;									// until it is correct
	}
	if (inputFile1 == "textFile1.txt")	// If they enter "textFile1.txt"...
	{
		cout << "The file " << inputFile1 << " has been opened and will be processed" << endl; // Tell them it was open successfully 
		OutputDivider(static_cast<ofstream&>(cout));	// Call OutputDivider to the function
		fin.open("textFile1.txt");	// Open the first text file
		cout << "Enter the name of the second input file: ";	// User must enter the name of the second text file
		cin >> inputFile2;
		while (inputFile2 != "textFile2.txt")	// If the user doesn't enter "textFile2.txt"...
		{
			OutputDivider(static_cast<ofstream&>(cout));
			cout << "File does not exist, try again." << endl;		// Tell them the file doesn't exist
			cout << "Enter the name of the second input file: ";	// and prompt them to enter it again
			cin >> inputFile2;										// until it is correct
		}
		if (inputFile2 == "textFile2.txt")	// If they enter "textFile1.txt"...
		{
			cout << "The file " << inputFile2 << " has been opened and will be processed" << endl;  // Tell them it was open successfully 
			OutputDivider(static_cast<ofstream&>(cout));											// (but don't open it yet)
			//fin.open("textFile2.txt");
		}
	}

}
//---------------------------------------------------------------------
//Function #3
//OutputHeading - This function prints the college name, exercise
//                number, and programmer name to the output file.
//---------------------------------------------------------------------
void OutputHeading(ofstream& fout)
{
	OutputDivider(fout);

	fout << setw((WIDTH + COLLEGE.length()) / 2) << COLLEGE << endl;	// Print Lab header to output file
	fout << setw((WIDTH + CST_PROGRAMMER.length()) / 2) << CST_PROGRAMMER << endl;
	fout << setw((WIDTH + CLASS_AND_LAB.length()) / 2) << CLASS_AND_LAB << endl;
	OutputDivider(fout);

}
//---------------------------------------------------------------------
//Function #4
//FillChArray   - This function reads the data character by character 
//                and stores data in a character array until the array
//				  is filled or all data has been read                
//---------------------------------------------------------------------
void FillChArray(ifstream& fin, char charRead1[], int& numberOfCharsF1) // charRead is all the stored characters in a text file in one array
{
	char aChar; // Temporary character to read every character from an input file (A, F, etc.)

	numberOfCharsF1 = 0; // number of Characters in file #2 is 284

	fin.get(aChar); // Read in a character to begin for loop

	while (numberOfCharsF1 < MAX_CHARACTERS && fin) // While the number of characters in a text file is less than 500 (the max amount of characters), 
												  // and data is being read in:
	{
		charRead1[numberOfCharsF1] = aChar; // Array charRead stores each element (0, 1 , 2, etc) as aChar, a character read in

		fin.get(aChar); // Grab the next input character

		numberOfCharsF1++; // Increment the number of characters in a text file
	}
		
}
//---------------------------------------------------------------------
//Function #5
//InitializeIntArray   - This function initializes each position of an
//						 integer array of 26 elements to 0 						            
//---------------------------------------------------------------------
void InitializeIntArray(int countChArray1[], int& numberOfInts1) // CountChArray1 is an int array from 0 to 26 with each element at 0
{
	int index; // Declare Loop Control Variable
	numberOfInts1  = 0; // Number of integers initializes to zero
	for (index = 0; index < MAX_LETTERS; index++) // Increment index as it approaches all 26 letters of the alphabet 
	{
		countChArray1[index] = 0; // Index (each element in the array) is initialized to zero, 26 times for each alphabetical letter
	}
}
//---------------------------------------------------------------------
//Function #6
//CountAlphabetCharacters   - This function counts the number of each
//							  letter of the alphabet found in a
//							  character array and store these counts
//							  in an integer array					 				            
//---------------------------------------------------------------------
void CountAlphabetCharacters(ofstream& fout, int countChArray1[], char charRead1[], int& numberOfCharsF1)
{
	int index; // Loop control variable
	int temp; // Temp is our variable to store the ASCII value of each character in the array countChArray
	char readChar; //readChar is our new variable to take in every character from a text file
	for (index = 0; index < numberOfCharsF1 ; index++) // numberOfCharF1 changes depending on the function call
													   // You are only reading in as many characters as in a text file
	{
		readChar = charRead1[index]; // readChar is set to each element of charRead (A, F, R, O, etc)

		readChar = static_cast<char>(toupper(readChar)); // Set each character to uppercase

		if (readChar >= 'A' && readChar <= 'Z') // Check if each character read from charRead is between A and Z, if so:
		{
			temp = static_cast<int>(readChar); // Make readChar it's corresponding ASCII value (A = 65; an integer)
			temp = temp - 65; // Temp becomes x element of countChArray depending on it's ASCII value (F - 65 = 5, temp becomes 5th element in CountChArray1)
			countChArray1[temp]++; // Increment the value of each respective element (A is zeroth element and increments to 27 for example,
								   // there are 27 A's in the text file read)
		}
	}
}
//---------------------------------------------------------------------
//Function #7
//CalculateTotal	   - This function calculates the total characters
//						 in a file 						 					            
//---------------------------------------------------------------------
void CalculateTotal(int countChArray1[], int numberOfCharsF1, int& totalCharacters1)
{
	totalCharacters1 = numberOfCharsF1; //Make a variable declaring the total characters in a text file
}
//---------------------------------------------------------------------
//Function #8
//CompareChArrays	   - This function compares the two character arrays
//						 position by position and counts the number of
//						 times that each array in the same position
//					     contains the same character					 				 					            
//---------------------------------------------------------------------
void CompareChArrays(char charRead1[], char charRead2[], int numberOfCharsF1, int numberOfCharsF2, int& sameCounter)
{
	int index = 0; // Loopo control variable
	
	for (index = 0; index < numberOfCharsF2; index++) //File two has fewer characters so it controls the loop to be shorter
	{
		if (charRead1[index] == charRead2[index])	//If any given element (A, ", !, etc) matches the same position as the other text file...
		{
			sameCounter++;	// Increment the counter for the same characters
		}
	}
	
}
//---------------------------------------------------------------------
//Function #9
//OutputChArray			 - This function outputs a label with the name
//						   of the array identifying the array that is 
//						   being printed						 		 					            
//---------------------------------------------------------------------
void OutputChArray(ofstream& fout, char charRead1[], char readChar, int N, int temp, string whichArray1, int numberOfCharsF1)
// numberOfCharsF1 is 459, numberOfCharsF2 is 346
{
	OutputDivider(fout);	//Call OutputDivider to the function
	fout << endl;
	int index;				// Placeholder for elements of array
	N = 1;					// N tells us the number of the line we're on
	

	fout << "The characters in " << whichArray1 << endl;	//String whichArray1 will change depending on the function call
	OutputDivider(fout);
	fout << "Line #: " << N << " ";		//Output line #
	for (index = 0; index < numberOfCharsF1; index++) // numberOfChars changes depending on function call
	{
		readChar = charRead1[index]; // readChar is set to each element of charRead (A, F, R, O, etc)
		fout << readChar;
		temp = static_cast<int>(readChar);	//Static cast temp, our placeholder variable, to an ASCII integer
		if (temp == 10)	// If the ASCII integer is 10, it's a newline space, meaning we need to separate the line
		{
			N++;	//Increment our line counter
			fout << "Line #: " << N << " ";	
		}		
	}
	fout << endl;
	OutputDivider(fout);
}
//---------------------------------------------------------------------
//Function #10
//OutputCountArray		 - This function outputs a label identifying
//						   which array data is being output, the first  
//						   13 letters of the alphabet in columns, the
//						   first 13 counts aligned under the letter
//						   headings, and the second 13 letters of the
//						   alphabet in the same columns as above					   					   						 		 					            
//---------------------------------------------------------------------
void OutputCountArray(ofstream& fout, int countChArray1[], string whichArray2)
{
	fout << endl;
	fout << "The count array is " << whichArray2 << endl;	// Print the counts of each alphabetical letter to the output file
	OutputDivider(fout);
	fout << setw(8) << "A" << setw(8) << "B" << setw(8) << "C" << setw(8) << "D"
		 << setw(8) << "E" << setw(8) << "F" << setw(8) << "G" << setw(8) << "H"
		 << setw(8) << "I" << setw(8) << "J" << setw(8) << "K" << setw(8) << "L"
		 << setw(8) << "M" << endl;
	OutputDivider(fout);
	fout << setw(8) << countChArray1[0] << setw(8) << countChArray1[1] << setw(8) << countChArray1[2]	// Each element in our array represents a different letter count
		<< setw(8) << countChArray1[3] << setw(8) << countChArray1[4] << setw(8) << countChArray1[5]
		<< setw(8) << countChArray1[6] << setw(8) << countChArray1[7] << setw(8) << countChArray1[8]
		<< setw(8) << countChArray1[9] << setw(8) << countChArray1[10] << setw(8) << countChArray1[11]
		<< setw(8) << countChArray1[12] << endl;
	OutputDivider(fout);
	fout << setw(8) << "N" << setw(8) << "O" << setw(8) << "P" << setw(8) << "Q"
		 << setw(8) << "R" << setw(8) << "S" << setw(8) << "T" << setw(8) << "U"
		 << setw(8) << "V" << setw(8) << "W" << setw(8) << "X" << setw(8) << "Y"
		 << setw(8) << "Z" << endl;
	OutputDivider(fout);
	fout << setw(8) << countChArray1[13] << setw(8) << countChArray1[14] << setw(8) << countChArray1[15]
		<< setw(8) << countChArray1[16] << setw(8) << countChArray1[17] << setw(8) << countChArray1[18]
		<< setw(8) << countChArray1[19] << setw(8) << countChArray1[20] << setw(8) << countChArray1[21]
		<< setw(8) << countChArray1[22] << setw(8) << countChArray1[23] << setw(8) << countChArray1[24]
		<< setw(8) << countChArray1[25] << endl;
	OutputDivider(fout);
}
//---------------------------------------------------------------------
//Function #11
//OutputTotal			 - This function outputs the total count of 
//						   letters with a label stating which array the
//						   count references 					   					   					 		 					            
//---------------------------------------------------------------------
void OutputTotal(ofstream& fout, int totalCharacters1, string whichArray3)
{
	

	fout << "The total characters for " << whichArray3 << ": " << totalCharacters1 << endl;	// Output the total characters for a file
	OutputDivider(fout);
}
//---------------------------------------------------------------------
//Function #12
//OutputCompareCount   - This function outputs the number of instances
//						 where the characters matched in the same
//						 position of both character arrays						   						   				   					   					 		 					            
//---------------------------------------------------------------------
void OutputCompareCount(ofstream& fout, int &sameCounter, string whichArray4, string whichArray5)
{
	OutputDivider(fout);
	fout << "There were a total of " << sameCounter << " times that "	// Output the total instances characters matched up between arrays
		 << whichArray4 << " and " << whichArray5
		 << " matched in the same positions!" << endl;
	OutputDivider(fout);
}
//---------------------------------------------------------------------
//BONUS Function #13
//EncryptMessage       - This function outputs the number of instances
//						 where the characters matched in the same
//						 position of both character arrays						   						   				   					   					 		 					            
//---------------------------------------------------------------------
void EncryptMessage(ofstream& fout, char charRead1[], int numberOfCharsF1)
  {
	int index; // Loop control variable
	int temp; // Temp is our variable to store the ASCII value of each character in the array countChArray
	char ch;
	char readChar; //readChar is our new variable to take in every character from a text fil
	fout << endl;
	fout << "BONUS" << endl;
	OutputDivider(fout);
	for (index = numberOfCharsF1 - 1; index >= 0; index--) // Because we are reading from the last character to the first character, numberOfChars - 1 
														   // gives us our last element. By decrementing index we read the elements from 458 - 0
	{
		readChar = charRead1[index]; // readChar is set to each element of charRead (A, F, R, O, etc)

		readChar = static_cast<char>(toupper(readChar)); // Set each character to uppercase

		temp = static_cast<int>(readChar);	// Static cast readChar into our intermediate variable temp as an integer
		if (temp == 10)	// If the ASCII value is 10, we know it's a newline character, and must space our lines
		{

			fout << endl;
		}	


		if (readChar >= 'A' && readChar <= 'Z') // This still reads our ASCII value as an integer and character,
												// Check if each character read from charRead is between A and Z, if so:
		{
			
			temp = temp - 10;					// Subtract 10 from temp
			ch = static_cast<char>(temp);		// Static cast temp to ch, a character
			
			fout << ch;							// Output ch
								   
			
		}
	}
}