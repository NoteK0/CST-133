//-----------------------------------------------------------------------------
//Exercise 2 Grading Block
//Name:  
//Grade:
//General Comments:
//  
//  
//  
//  
//Standard Requirements
//  Requirements met as specified in the CST Program Style Requirements 
//    document
//  Which includes but not limited to:
//    Program Creation
//    Documentation
//    File Requirements
//    Constants
//    Variables 
//    Code
//
//Comments:
//  
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//Program Specifications
//  Constants created for 
//    college name
//    student name 
//    exercise number
//    screen width
//    sentinel value '#'
//    number of judges
//
//  Heading for the exercise output to the output file 
//
//Comments:
//  
//Points Lost -------------------------------------------------------------> 
//
//Problem #1 - Even/Odd Sum - Exercise 6 from the textbook
//  All input for the problem is read and processed
//  Output of Divider used to separate output as needed
//  Centered output problem heading for the exercise
//  Column heading output to identify the data in the columns
//  File Processing while Loop Used with a primer & a changer
//  All numbers read, one at a time, echo printed to output
//    file, aligned in the column
//  Even & Odd sum calculated correctly &
//    Output under the correct columns
//
//Comments:
//    
//    
//      
//Points Lost -------------------------------------------------------------> 
//
// Problem #2 - Dancing with the Faculty
//  Output of Divider used to separate output as needed
//  Output Centered problem heading for the exercise
//  Set formatting of floating point values to 1 decimal place
//  File processing loop used with a primer and a changer
//  getline used for input of name as a string
//  # of contestant calculated (incremented not assigned)
//  name and # of contestant output to the output file
//  For loop used to read judges' scores
//  Each score read from the input file
//    ONE variable used for the score
//  Output the score # and the score to the output file
//  Total score calculated correctly, dropping lowest score
//  Lowest score determined correctly based on the 5 scores
//  Lowest score set initially to an invalid data value
//  Final score for each contestant calculated correctly 
//    based on number of judges and output to the output file
//  Winner's name and final score determined and output to the output file
//  Efficient testing used for this solution
//
//Comments:
//  
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//  Total Possible Lab Grade ----------------------------------------------> 100
//  Total Points Lost -----------------------------------------------------> 
//  Actual Lab Grade ------------------------------------------------------> 
//----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//Programmer's Name:  Chad Cole
//Program:  Exercise 2
//Program Description (IPO):
// The logical output file for ex2Out.txt is opened
// Problem #1:
//  Initialize the odd & even count, the odd & even sum
//  The logical input file for ex2Numbers.txt is opened
//  First number is read from the logical input file for ex2Numbers.txt
//  While numbers are in the logical input file for ex2Numbers.txt:
//    Determine if the number is odd or even
//     increment the appropriate count & add the value to either
//     the even or odd sum. (O is not added to either count or sum)
//    The number, the current even sum, the current odd sum are output to the
//     output file, ex2Out.txt
//    The even count & the odd count are output to the 
//     logical output file for ex2Out.txt
//  The logical input file for ex2Numbers.txt is closed  
//
//Problem #2 - Dancing with the Faculty 
//Initialize scores
// Initalize contestant names
// Initialize winning contestant and their name to preset values
// Grab data from scores.txt
// While data is being read...Initialize score number, total score, and lowest score
// Initialize a for loop with how many times it needs to repeat
// Increment score number and output it
// Determine if their score is the lowest score
// Determine the final score of the contestant
// Update if this score is the highest score and winning contestant
// Output contestant and their scores to output file
// Repeat until all contestants are output
// Output winning contestant and their score
//-----------------------------------------------------------------------------


#include <iostream> //Include input output stream


#include <fstream> //Include file stream


#include <iomanip> //Include input output manipulation


#include <string> //Include strings


using namespace std; //Use namespace

//Set constants

const string COLLEGE = "SUNY Broome Community College"; //Constants for Problem 1
const string CST_PROGRAMMER = "Chad Cole";
const string CLASS_AND_LAB = "CST 133 - Exercise 2";
const string EVEN_AND_ODD_COUNT = "Even and Odd Count";
const int NUMBER_OF_JUDGES = 5;
const int WIDTH = 80;


const string DANCING_WITH_THE_FACULTY = "Dancing With the Faculty"; //Constants for Problem 2

void OutputDivider(ofstream& fout); //Set a function for output divider
void OutputHeading(ofstream& fout); //Set a function for output heading
int main() {
    
    int stringLength1; //Variables for Problem 1
    int stringLength2;
    int stringLength3;
    int stringLength4;
    int stringLength5;
    int evenSum = 0; 
    int oddSum = 0; 
    int value;

    ifstream fin;
    ifstream fin2;
    ofstream fout;

    
    string name; //Variables for Problem 2
    int contestantNumber;
    
    double score;
    int scoreNumber;
    
    double lowestScore;
    double totalScore;
    double finalScore;
    double highestScore;
    string winningContestantName;

    //Problem 1

    
    fin.open("Ex2Numbers.txt"); //Open input and output files
    fout.open("Ex2Out.txt");

    
    stringLength1 = static_cast<int>(COLLEGE.length()); //Static cast string length to college length and so forth
    stringLength2 = static_cast<int>(CST_PROGRAMMER.length());
    stringLength3 = static_cast<int>(CLASS_AND_LAB.length());
    stringLength4 = static_cast<int>(EVEN_AND_ODD_COUNT.length());
    stringLength5 = static_cast<int>(DANCING_WITH_THE_FACULTY.length());
    fout << fixed << setprecision(1);


    OutputHeading(fout); //Call OutputHeading function to main
    OutputHeading((ofstream&)cout);
    cout << setw((WIDTH + stringLength1) / 2) << COLLEGE << endl; //Output header to screen
    cout << setw((WIDTH + stringLength2) / 2) << CST_PROGRAMMER << endl;
    cout << setw((WIDTH + stringLength3) / 2) << CLASS_AND_LAB << endl;


    OutputDivider((ofstream &)cout); //Call OutputDivider function to main

    fout << setw((WIDTH + COLLEGE.length()) / 2) << COLLEGE << endl;
    fout << setw((WIDTH + CST_PROGRAMMER.length()) / 2) << CST_PROGRAMMER << endl;
    fout << setw((WIDTH + CLASS_AND_LAB.length()) / 2) << CLASS_AND_LAB << endl;
    OutputDivider(fout); //Call OutputDivider function to main (again but for fout)
    fout << setw((WIDTH + EVEN_AND_ODD_COUNT.length()) / 2) << EVEN_AND_ODD_COUNT << endl;
    cout << setw((WIDTH + stringLength4) / 2) << EVEN_AND_ODD_COUNT << endl;
    fout << setw(20) << "Number" << setw(25) << "Even Sum" << setw(25) << "Odd Sum" << endl;

    cout << setw(20) << "Number" << setw(25) << "Even Sum" << setw(25) << "Odd Sum" << endl; //Output header to console


    
    while (fin >> value) //Loop through each number in the input file
    { 
        cout << setw(20) << value;  //Output the number to console
        fout << setw(20) << value;  //Output the number to output file

        
        if (value % 2 == 0) //Update evenSum and output to console and file
        {
            evenSum += value;
            
        }
        else //Update oddSum and output to console and file
        {  
            oddSum += value;
            
        }

        cout << setw(25) << evenSum;
        fout << setw(25) << evenSum;
        cout << setw(25) << oddSum;
        fout << setw(25) << oddSum;

        cout << endl; //Move to the next line in the console
        fout << endl; //Move to the next line in the output file
    }

   
    fin.close(); //Close input file

    //Problem 2


    fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl; //Make a new heading
    cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
    cout << setw((WIDTH + DANCING_WITH_THE_FACULTY.length()) / 2) << DANCING_WITH_THE_FACULTY << endl;
    fout << setw((WIDTH + DANCING_WITH_THE_FACULTY.length()) / 2) << DANCING_WITH_THE_FACULTY << endl;
    cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
    fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

    
    fin2.open("scores.txt"); //Open new input file

    
    contestantNumber = 1;  //Initialize contestant and winner variables outside of loop
    highestScore = -1;
    winningContestantName = "";

    getline(fin2, name, '#'); //Kickstart the loop by grabbing first contestant's name
    while (fin2)
    {
       
        
        scoreNumber = 1; //Set score number, total score, and lowest scores outside of for loop
        totalScore = 0;
        lowestScore = 11;
      
        
        cout << "Contestant # " << contestantNumber << " name: " << name << endl; //Heading for a contestant
        fout << "Contestant # " << contestantNumber << " name: " << name << endl;

        for (int index = 2; index <= 6; index++) //Set up LCV
        {
            fin2 >> score; //Grab score from scores.txt
            cout << "Score # " << scoreNumber << ":" << setw(10); //Output to console score number
            fout << "Score # " << scoreNumber << ":" << setw(10);
            scoreNumber++; //Increment score number
            cout << score << endl; //Output data from text file
            fout << score << endl;
            
            totalScore += score; //Total score is the sum of all scores
            if (score < lowestScore) //If score is lower than the lowest score...
            {
                lowestScore = score; //Update the lowest score
            }
            
        }

        
        
        finalScore = totalScore - lowestScore; //Contestant's final score is total score minus lowest score...
        cout << setprecision(2);
        fout << setprecision(2);
        finalScore /= ( NUMBER_OF_JUDGES - 1); //Divided by 5 minus 1
        cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
        fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
        cout << "Final Score is: " << setw(4) << finalScore << endl; //Output the final score to console
        fout << "Final Score is: " << setw(4) << finalScore << endl;
        cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
        fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
        if (finalScore > highestScore) //If the final score is greater than the highest score...
        {
            highestScore = finalScore; //Update the highest score
            winningContestantName = name; //Update the winning contestant's name
        }

        fin2.ignore(100, '\n');
        getline(fin2, name, '#');
        
        contestantNumber++;
    }

    cout << "The winning contestant is... " << winningContestantName << "! With a score of " //Output winning contestant and their score
         << highestScore << "!" << endl;
    fout << "The winning contestant is... " << winningContestantName << "! With a score of "
         << highestScore << "!" << endl;

    fin2.close(); //Close input and output files
    fout.close();
    return 0; //End program
}

//OutputDivider: This function will print 
//an additional divider line to the screen
void OutputDivider(ofstream& fout)
{
    fout << setfill('-')
        << setw(WIDTH)
        << '-' << setfill(' ') << endl;
    

}
//OutputHeading: This function will
//print a heading to the stream 
//passed in
void OutputHeading(ofstream& fout)
{
    OutputDivider(fout);

    fout << setw((CST_PROGRAMMER.length() + WIDTH) / 2)
        << CST_PROGRAMMER << endl;
    OutputDivider(fout);

}


