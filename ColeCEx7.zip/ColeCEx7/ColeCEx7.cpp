//-----------------------------------------------------------------------------
//Exercise 7 Grading Block
//Name:  
//Grade: 
//General Comments:
//  
//  
//  
//  
//Standard Requirements
//  Requirements met as specified in the CST Program Style Requirements 
//    document
//  Which includes but not limited to:
//    Program Creation
//    Documentation
//    File Requirements
//    Constants
//    Variables 
//    Code
//Comments:
//  
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//General Function Specs:
//  Functions prototypes correctly placed
//  Functions correctly named following course specifications
//  Function calls appropriately placed and used in program
//  Function definitions correctly placed
//  Documentation above EACH function following course specifications
//  Functions prototypes and definitions appear in the
//   ORDER listed below in the correct location
//  Functions blocked appropriately
//Points will be deducted if necessary in the individual functions
//
//Program Specifications
//  Constants created for 
//    college name
//    student name 
//    course and exercise heading
//    screen width
//    array size
//
//  Heading for the exercise output to the output file 
//    SoftballResults.txt
//
//Comments:
//  
//Points Lost -------------------------------------------------------------> 
//
//Declarations
//  
//Struct Definition
//  Struct defined above the main
//  Contains the following members:
//    name, position, number, atBats, hits, basesTaken, 
//    ranking, battingAverage, sluggingAverage
//  Indentation and naming styles for struct followed
//
//  an array of max size 15 of the struct
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//Files
//  Correct input file - SoftballData.txt and PlayerPos.txt opened/closed 
//    in the main
//  Correct output file - SoftballResults.txt opened/closed in the main 
//Comment:
//
//    
//Points Lost -------------------------------------------------------------> 
//
//1.InputPlayerData
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly reads data into array of struct, returns
//    the array and the tag field
//  Priming read used
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//2.CalculateBattingAverage
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly calculates ONE batting average
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//3.CalculateSluggingAverage
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly calculates ONE slugging average
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//4.CalculateAverage
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly calculates ALL batting & slugging averages
//   for each player
//
//  Comment:
//
//Points Lost -------------------------------------------------------------> 
//
//5.InitializeRanking
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly initializes each ranking in the array of structs
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//6.CalculateRanking
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly and efficiently calculates the ranking of each player based on
//    the batting average
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//7.OutputPlayerData
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  All output to the output file
//  Heading printed above data
//  All struct data printed in columns, 
//    strings left aligned, values right aligned
//
//Comment:
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//8.OutputOverHits
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  All output to the output file
//  Heading printed above data stating value over amount
//  Column headings for data output
//  name and hits of players over number of hits passed in output 
//    in aligned columns
//
//Comment:
//    
//  
//Points Lost -------------------------------------------------------------> 
//
//9.InputPlayerPositions
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly reads data into array of strings, returns
//    the array and the tag field
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//10.OutputPlayerByPosition
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  All output to the output file
//  Heading printed above data stating value over amount
//  Column headings for data output
//  name, position & number output, order of output is by
//    position from the position array
//
//Comment:
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//11.Swap
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//
//Comment:
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//12.IndexOfSmallest
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//
//Comment:
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//13.SelectionSort
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly sorts player array by jersey number
//
//Comment:
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//14.OutputPlayerByNumber
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  All output to the output file
//  Heading printed above data stating value over amount
//  Column headings for data output
//  name and number output, order of output is by jersey number
//
//Comment:
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//Miscellaneous Errors
//  Errors not anticipated by your professors that violate
//  structured programming rules, program specs, etc...
//
//Comment:
//      
//Possible Points ---------------------------------------------------------> 200
//Total Points Lost ------------------------------------------------------->  
//Exercise Grade ---------------------------------------------------------->  
//-----------------------------------------------------------------------------
//Programmer's Name: Chad Cole
//Program: Exercise 7
//Program Flow (IPO):
//  No inputs from the user
//  Program will read in data from a text file and process it into members
//  of a structure
//  Program will print dividers and header
//  Program static casts and calculates variables for two different averages
//  Program initializes all elements of an array to 0
//  Program calculates rankings upon members of a structure based off
//  averages calculated and for loop reads
//  Program outputs data from structure to an output file
//  Program checks if any players made over 10 and or 20 hits
//  Program reads player positions into a string array
//  Program calculates and reshuffles players by jersey number by comparison
//  to a smallest and minimum index
//
//-----------------------------------------------------------------------------

#include <iostream> //Include input output stream

#include <fstream> //Include file stream


#include <iomanip> //Include input output manipulation


#include <string> //Include strings


using namespace std; //Use namespace

//Set constants
const string COLLEGE = "SUNY Broome Community College"; //Constants for Problem 1
const string CST_PROGRAMMER = "Chad Cole";
const string CLASS_AND_LAB = "CST 133 - Exercise 7";
const int WIDTH = 100;
const int MAX_INPUTS = 15; // Character limit for input lines read in
const char DIVIDER = '-';

struct playerRecord    // Our structure
{
	string name; // Player's name
	string position; // Player's position
	int number = 0; // Player's jersey number
	int atBats = 0; // Player's at bats
	int hits = 0; // Player's hits
	int basesTaken = 0; // Player's bases taken
	int ranking = 0; // Player's ranking on the team
	double battingAverage = 0.0; // Player's batting average
	double sluggingAverage = 0.0; // Player's slugging average
};

void OutputDivider(ofstream& fout); // Function prototypes
void OutputHeading(ofstream& fout);
void InputPlayerData(ifstream& fin, playerRecord& onePlayer, playerRecord player[], int& tagField);
double CalculateBattingAverage(playerRecord& onePlayer);
double CalculateSluggingAverage(playerRecord& onePlayer);
void CalculateAverages(playerRecord player[], int tagField);
void InitializeRankings(playerRecord player[], int tagField);
void CalculateRanking(playerRecord onePlayer, playerRecord player[], int tagField);
void OutputPlayerData(ofstream& fout, playerRecord onePlayer, playerRecord player[], int tagField);
void OutputOverHits(ofstream& fout, playerRecord player[], int tagField, int numberOfHits);
void InputPlayerPosition(ifstream& fin, string playerPosition[], int& playerPosSize);
void SelectionSort(playerRecord player[], int tagField);
int IndexOfSmallest(playerRecord player[], int tagField, int index);
void Swap(int& first, int& second);
void OutputPlayerByPosition(ofstream& fout, playerRecord player[], string playerPosition[], int tagField, int playerPosSize);
void OutputPlayerByNumber(ofstream& fout, playerRecord player[], int tagField);

int main(void)
{
	int stringLength1; //Variables for Problem 1
	int stringLength2;
	int stringLength3;
	int index = 0;   
	int playerPosSize = 0;
	int first = 0;
	int second = 0;

	ifstream fin; // SoftballData.txt
	ofstream fout; // SoftballResults.txt

	playerRecord player[MAX_INPUTS]; // Our ARRAY of STRUCTURES. Array of players in our list
	int tagField = 0; // Our tag field
	string playerPosition[MAX_INPUTS];
	playerRecord onePlayer; // Our EDITABLE OBJECT in our STRUCTURE. Object that changes attributes per player

	stringLength1 = static_cast<int>(COLLEGE.length()); //Static cast string length to college length and so forth
	stringLength2 = static_cast<int>(CST_PROGRAMMER.length());
	stringLength3 = static_cast<int>(CLASS_AND_LAB.length());

	fin.open("SoftballData.txt");		   // Open the input file

	fout.open("SoftballResults.txt"); // Open the output file

	fout << fixed << setprecision(3); // Set decimal points to three values

	OutputHeading(fout); // Call OutputHeading
	InputPlayerData(fin, onePlayer, player, tagField); // Call InputPlayerData
	CalculateAverages(player, tagField); // Call CalculateAverages
	InitializeRankings(player, tagField); // Call InitializeRankings
	CalculateRanking(onePlayer, player, tagField); // Call CalculateRanking
	OutputPlayerData(fout, onePlayer, player, tagField); // Call OutputPlayerData
	OutputOverHits(fout, player, tagField, 10); // Call OutputOverHits with '10'
	OutputOverHits(fout, player, tagField, 20); // Call OutputOverHtis with '20'

	fin.close(); // Close the input file
	fin.open("PlayerPos.txt"); // Open the next input file

	InputPlayerPosition(fin, playerPosition, playerPosSize); // Call InputPlayerPosition
	IndexOfSmallest(player, tagField, index); // Call IndexOfSmallest
	Swap(first, second); // Call Swap
	OutputPlayerByPosition(fout, player, playerPosition, tagField, playerPosSize); // Call OutputPlayerByPosition
	OutputPlayerByNumber(fout, player, tagField); // Call OutputPlayerByNumber

	fin.close(); // Close the input file
	fout.close(); // Close the output file

	return 0; // End program. I may never see you again Ms. Sedelmeyer!!
}
//---------------------------------------------------------------------
//Function #1
//OutputDivider - This function prints a divider to the output file.            
//---------------------------------------------------------------------
void OutputDivider(ofstream& fout)
{
	fout << setfill(DIVIDER) << setw(WIDTH + 1) << ' ' << setfill(' ') << endl; //Sets a divider as a callable function


}
//---------------------------------------------------------------------
//Function #2
//OutputHeading - This function prints the college name, exercise
//                number, and programmer name to the output file.
//---------------------------------------------------------------------
void OutputHeading(ofstream& fout)
{
	OutputDivider(fout); // Call OutputDivider 

	fout << setw((WIDTH + COLLEGE.length()) / 2) << COLLEGE << endl;	// Print Lab header to output file
	fout << setw((WIDTH + CST_PROGRAMMER.length()) / 2) << CST_PROGRAMMER << endl; // Do the same for rest of header
	fout << setw((WIDTH + CLASS_AND_LAB.length()) / 2) << CLASS_AND_LAB << endl;
	OutputDivider(fout); // Call OutputDivider 

}
//---------------------------------------------------------------------
//Function #3
//InputPlayerData - This function will read the data from the input
//                  file of unknown length into the array of structures
//---------------------------------------------------------------------
void InputPlayerData(ifstream& fin, playerRecord& onePlayer, playerRecord player[], int& tagField)
{
	while (fin && tagField < MAX_INPUTS) // While fin has data in it and tagfield is less than max inputs
	{
		getline(fin, player[tagField].name); //Input the player name into the structure from the data file
		getline(fin, player[tagField].position); // Input player position
		fin >> player[tagField].number; // Input player number
		fin.ignore(100, '\n');
		fin >> player[tagField].atBats; // Input player atbats
		fin.ignore(100, '\n');
		fin >> player[tagField].hits; // Input player hits
		fin.ignore(100, '\n');
		fin >> player[tagField].basesTaken; // Input player bases taken
		fin.ignore(100, '\n');
		tagField++; // Increment tagfield
	}

}
//---------------------------------------------------------------------
//Function #4
//CalculateBattingAverage - This function will calculate the batting 
//							average of one player                  
//---------------------------------------------------------------------
double CalculateBattingAverage(playerRecord& onePlayer) // Accessing specific attributes of object onePlayer in structure playerRecord
{
	return static_cast<double>(onePlayer.hits) / onePlayer.atBats; // You can return entire statements
	// We are accessing int hits div by int atBats at object onePlayer in structure playerRecord
}
////---------------------------------------------------------------------
////Function #5
////CalculateSluggingAverage - This function will calculate the slugging
////							 average of one player              
////---------------------------------------------------------------------
double CalculateSluggingAverage(playerRecord& onePlayer) // Accessing specific attributes of object onePlayer in structure playerRecord
{
	return static_cast<double>(onePlayer.basesTaken) / onePlayer.atBats; // You can return entire statements
	// Static cast one side or else it will not return correctly
	// We are accessing int basesTaken div by int atBats at object onePlayer in structure playerRecord
}
//---------------------------------------------------------------------
//Function #6
//CalculateAverages - This function will calculate the batting and
//					  slugging average of all players 							           
//---------------------------------------------------------------------
void CalculateAverages(playerRecord player[], int tagField)
{
	for (int index = 0; index < tagField; index++) // When index is 0, index is less than tagfield, index increments
	{
		player[index].battingAverage = CalculateBattingAverage(player[index]); // Player at x element in batting average is result of 
																			   // the function calculating batting aveage at x element
		player[index].sluggingAverage = CalculateSluggingAverage(player[index]); // Player at x element in slugging average is result of
																				 // the function calculating slugging aveage at x element
	}
}
//---------------------------------------------------------------------
//Function #7
//InitializeRankings - This function will initialize the ranking member
//					   of the struct for ALL players that are stored in 
//					   the array of structures, player					  						           
//---------------------------------------------------------------------
void InitializeRankings(playerRecord player[], int tagField)
{
	for (int index = 0; index < tagField; index++) // When index is 0, index is less than tagfield, index increments
	{
		player[index].ranking = 0; // Accessing array of structure player[] in structure PlayerRecord and setting it equal to 0
	}
}
//---------------------------------------------------------------------
//Function #8
//CalculateRanking  - This function will determine the rank of each
//					  player based on batting average in the array of
//					  structures, player					   					  					  						           
//---------------------------------------------------------------------
void CalculateRanking(playerRecord onePlayer, playerRecord player[], int tagField)
{
	int index; // Initialize index
	int numberOfRankings = 0; // Initialize numberOfRankings to 0 (we increment rankings)
	int currentRank = 1; // Initialize currentRank (we increment this every time a new rank is set)
	double highestBattingAverage; // Initialize highestBatingAverage
	int highestIndex; // Initialize highestindex 

	while (numberOfRankings < tagField) // tagField is essentially our number of players (13)
	// This loop continually compares 13 instances of different ranks and sorts them accordingly
	{
		highestBattingAverage = 0.00; // Initialize our highest batting average
		highestIndex = -1; // Ensure our highest index is out of bounds
		for (index = 0; index < tagField; index++) // While we are reading in 13 players
		{
			if (player[index].battingAverage > highestBattingAverage && player[index].ranking == 0) // One equal sign means you are initializing it, two means you're testing it
	// If player at element index is greater than the current highest batting average and player at element index is equal to zero
			{
				highestBattingAverage = player[index].battingAverage; // Save this batting average as the highest
				highestIndex = index; // Save our new highest index
			}	
		}
		numberOfRankings++; // One ranking has been calculated, increment it
		player[highestIndex].ranking = currentRank; // The player with the highest index gets rank 1
		currentRank++;;  // The next highest index will receive rank 2 and so forth
	}
}
//---------------------------------------------------------------------
//Function #9
//OutputPlayerData  - This function will output all the members of
//					  struct for each player to the output file,
//					  SoftballResults.txt					   					  					  						           
//---------------------------------------------------------------------
void OutputPlayerData(ofstream& fout, playerRecord onePlayer, playerRecord player[], int tagField)
{

	int index; // Local incrementer variable
	fout << "Player" << setw(40) << "#" << setw(14) << "Position" << setw(6) << "AB" // Set up header
		<< setw(5) << "H" << setw(5) << "BT" << setw(7) << "BA" << setw(9) << "SLG%"
		<< setw(8) << "Rank" << endl;

	OutputDivider(fout); // Call OutputDivider 
	for (index = 0; index < tagField; index++) // While we are reading in 13 players
	{

		fout << left << setw(25) << player[index].name << right << setw(22) << player[index].number // Output each member of player at index element 
			<< setw(13) << player[index].position << setw(6) << player[index].atBats
			<< setw(5) << player[index].hits << setw(5) << player[index].basesTaken
			<< setw(8) << player[index].battingAverage << setw(8)
			<< player[index].sluggingAverage << setw(7) << player[index].ranking << endl;
	}
}
//---------------------------------------------------------------------
//Function #10
//OutputOverHits    - This function will output the names and the
//					  number of hits of each player where the number 
//					  of hits is over a value passed in					  				 					   					  					  						           
//---------------------------------------------------------------------
void OutputOverHits(ofstream& fout, playerRecord player[], int tagField, int numberOfHits)
{
	int index; // Local incrementer variable
	int overHits = 0; // Initialize overHits
	OutputDivider(fout); // Call OutputDivider
	fout << "These players had more than " << numberOfHits << " hits:" << endl; // Set up header
	fout << "Name" << setw(20) << "Hits" << endl;
	OutputDivider(fout); // Call OutputDivider
	if (numberOfHits == 10) // If numberOfHits = 10
	{
		for (index = 0; index < tagField; index++) // While reading in 13 players
		{
			if (player[index].hits > 10) // Check to see if the player has less than 10 hits at the hits attribute
			{
				fout << left << setw(21) << player[index].name << setw(10) << player[index].hits << right << endl; // Output if so
				overHits++; // Increment our overHits
			}
		}
		if (overHits == 0) // If overHits is 0
		{
			fout << "No players had more than " << numberOfHits << " hits. Swing batter batter!" << endl; // No players must have been able to hit over
		}
	}
	else
	{
		for (index = 0; index < tagField; index++) // Check to see if the player has less than 10 hits at the hits attribute
		{
			if (player[index].hits > 20) // Check to see if the player has less than 20 hits at the hits attribute
			{
				fout << left << setw(21) << player[index].name << setw(10) << player[index].hits << right << endl; // Output if so
				overHits++;// Increment our overHits
			}
		}
		if (overHits == 0)// If overHits is 0
		{
			fout << "No players had more than " << numberOfHits << " hits. Swing batter batter!" << endl; // No players must have been able to hit over
		}
	}

}
//---------------------------------------------------------------------
//Function #11
//InputPlayerPosition    - This function will input into an array of
//						   string, the 9 positions on a softball team in 
//						   the order in which they are announced at games						   				  				 					   					  					  						           
//---------------------------------------------------------------------
void InputPlayerPosition(ifstream& fin, string playerPosition[], int& playerPosSize)
{
	string string1; // Temp string to read and store words
	int index = 0; // Incrementer variable

	fin >> string1; // Primer read since while (fin) needs a primer
	while (fin) // While there is data in the input file
	{
		playerPosition[index] = string1; // Player position at x iteration is equal to string1
		index++; // Increment index
		playerPosSize++; // Increment our tag field
		fin >> string1; // New read
	}
}
//---------------------------------------------------------------------
//Function #12
//SelectionSort           - Helper function	to find the smallest index
//							in an array and keep reorganizing each element
//							until it reads from smallest to largest		   						   				  				 					   					  					  						           
//---------------------------------------------------------------------
void SelectionSort(playerRecord player[], int tagField)
{
	int smallestIndex; // Variable to keep track of the smallest index
	int index; // Incrementer variable

	for (index = 0; index < tagField - 1; index++) // While we are reading in our 13 players minus 1
	{
		smallestIndex = IndexOfSmallest(player, tagField, index); // Smallest index is equal to function call IndexOfSmallest

		Swap(player[index].number, player[smallestIndex].number); // Swap function to swap smallest index and loop index
	}
}
//---------------------------------------------------------------------
//Function #13
//IndexOfSmallest         - Helper function to calculate a minimum
//							index and update it when it is smaller
//							than the smallest index				   						   				  				 					   					  					  						           
//---------------------------------------------------------------------
int IndexOfSmallest(playerRecord player[], int tagField, int index)
{
	int smallestIndex; // Variable to keep track of the smallest index
	int minIndex; // Incrementer variable

	smallestIndex = index; // smallestIndex equals index

	for (minIndex = index + 1; minIndex < tagField; minIndex++) // while we read in minIndex plus 1
	{
		if (player[minIndex].number < player[smallestIndex].number) // Check if minIndex is smaller than our smallestIndex
		{
			smallestIndex = minIndex; // If so, update it
		}
	}

	return smallestIndex; // Return the value calculated since we changed it

}
//---------------------------------------------------------------------
//Function #14
//Swap                     - Helper function to swap two variables in
//							 a search for the smallest number					   						   						   				  				 					   					  					  						           
//---------------------------------------------------------------------
void Swap(int& first, int& second)
{
	int temp;

	temp = first; // temp = first
	first = second; // first = second
	second = temp; // second = temp
}
//---------------------------------------------------------------------
//Function #15
//OutputPlayerByPosition   - This function will output to the output
//							 file, 1) the player's name, 2) the player�s 
//							 position and 3) the player�s number in the
//							 order by the positions in the playerPosition
//							 array						   						   						   				  				 					   					  					  						           
//---------------------------------------------------------------------
void OutputPlayerByPosition(ofstream& fout, playerRecord player[], string playerPosition[], int tagField, int playerPosSize)
{
	int index;
	int index2;

	OutputDivider(fout); // Call OutputDivider
	fout << "Player name" << setw(30) << "Player position" << setw(30) // Set up header
		 << "Player number" << endl;
	OutputDivider(fout); // Call OutputDivider

	for (index = 0; index < playerPosSize; index++) // While we are reading in the 9 positions
	{
		for (index2 = 0; index2 < tagField; index2++) // While we are reading in the 13 players
		{
			if (playerPosition[index] == player[index2].position) // If playerposition at x element is equal to the position in player at x element
			{
				fout << left << setw(30) << player[index2].name << setw(20) <<  playerPosition[index] << right << setw(15) << player[index2].number << endl;
				// Output name position and number to the screen by position
			}
		}
	}
}
//---------------------------------------------------------------------
//Function #16
//OutputPlayerByNumber    - This function will output to the output
//							file, the player's name and the player�s
//							number in the order by their jersey number				   						   				  				 					   					  					  						           
//---------------------------------------------------------------------
void OutputPlayerByNumber(ofstream& fout, playerRecord player[], int tagField)
{
	int index; // Incrementer variable
	OutputDivider(fout); // Call OutputDivider
	fout << "Player name" << setw(33) << "Player jersey number" << endl; // Set up header
	OutputDivider(fout); // Call OutputDivider
	for (index = 0; index < tagField; index++) // While we are reading in the 13 players
	{
		fout << left << setw(25) << player[index].name << right << setw(9) << player[index].number << endl; // Output the name and jersey number by jersey number
	}

}