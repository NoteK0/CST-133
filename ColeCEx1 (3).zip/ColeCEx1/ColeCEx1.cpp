//-----------------------------------------------------------------------------
//Exercise 1 Grading Block
//Name:  
//Grade:
//General Comments:
//  
//  
//  
//  
//Standard Requirements
//  Requirements met as specified in the document CSTProgram Style Requirements
//  Which includes but not limited to:
//    Program Creation
//    File Requirements
//    Documentation
//    Constants
//    Variables 
//    Code
//
//Comments:
//  
//  
//  
//Points Lost ------------------------------------------------------------->
//
//Program Specifications
//  Constants created for 
//  College name
//  Student name
//  Exercise heading
//  Screen width
//  Sentinel value
//
//  Heading for the exercise output to the screen & output file 
//
//Comments: 
//
//Points Lost ------------------------------------------------------------->
//
//Problem #1 - Snow Amounts
// Output of Divider used to separate output as needed 
//   to the screen & to the output file
// Output of problem heading/column headings as specified to the output file
// Output of CENTERED problem heading to the output file
// Number of Days of snow input from user
//  Meaningful prompt used, input on same line as prompt
// For loop used correctly for processing of days of snow:
//  Amount of snow input from the user
// Meaningful prompt used, input on same line as prompt
// Most Snow amount and day set correctly
// Initially set to -1, tested
//  and re-set if another day had more snow
// Snow amount accumulated correctly
// Output of day number and snow amount for each day 
//   to output file, ex1Out.txt
// Output of total, most snow day and most amount 
//   to the output file, ex1Out.txt
//
//Comments:
//  
//
//
//Points Lost ------------------------------------------------------------->
//
//Problem #2 - Character Counting
// Output of Divider used to separate output as needed
// Output of CENTERED problem heading to the output file
// Sentence input from the user
// Meaningful prompt used, input on next line below prompt
// Ignore used to skip any remaining chars from input from previous problem
// get() used to input ONE char and char echo printed to output file
// Sentinel while loop used, includes primer & changer
//  stops when # is encountered
// toupper() correctly used on ch to decrease testing
// testing and incrementing of correct counts for vowels, 
//  blanks & other chars
// Output of the counts after chars read until sentinel
//
//Comment:   
//  
//
//
//Points Lost ------------------------------------------------------------->
//
//  Total Possible Lab Grade ----------------------------------------------> 100
//  Total Points Lost -----------------------------------------------------> 
//  Actual Lab Grade ------------------------------------------------------> 
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//Programmer's Name: Chad Cole
//Program:  Exercise 1
//Program Flow (IPO):
//
//Problem #1:
//  Initialize number of days of snow
//  Initialize snow for each day
//  Input number of days of snow
//  For the number of days of snow:
//    Input inches per day
//    Determine which is the greatest amount of snow
//      based on the inputs given
//    Accumulate total snowfall
//    Output numbers of days of snow
//  Output amount of snow per day and which day had the most snow
//
//Problem #2:
//  Initialize the total vowel count, total blank count and total other count
//  Output a prompt asking user to write a sentence ending with #
//  Input a sentence
//  While the character is not the sentinel:
//    Output the character to the output file
//    Determine which counter to increment based on if the character is a vowel,
//    a blank or another character
//    Input data from sentinel while loop to output file
//  Output collected data to the logical output file,Ex1Out.txt
//
// The logical output file for ex1Out.txt is closed
//-----------------------------------------------------------------------------

//Include input output stream
#include <iostream>

//Include file stream
#include <fstream>

//Include input output manipulation
#include <iomanip>

//Include strings
#include <string>

//Use namespace
using namespace std;

//Set constants
//Constants for Problem 1
const string COLLEGE = "SUNY Broome Community College";
const string CST_PROGRAMMER = "Chad Cole";
const string CLASS_AND_LAB = "CST 133 - Exercise 1";
const int WIDTH = 80;

//Constants for Problem 2

const string SNOW_FALL_AMOUNTS = "Snow Fall Amounts";

//Constants for Problem 3
const string SENTENCE_ANALYSIS = "Sentence Analysis";
const char SENTINEL = '#';

void OutputDivider(ofstream& fout);
void OutputHeading(ofstream& fout);

//Set variables
int main(void)
{
	//Variables for Problem 1
	
	int stringLength1;
	int stringLength2;
	int stringLength3;
	double snowfallAmount;

	//Variables for Problem 2
	int daysOfSnow;
	int index;
	double totalSnowFall;
	int mostSnowDay;
	double mostSnow;
	
	int count;
	ifstream fin;
	ofstream fout;
	int stringLength4;

	//Variables for Problem 3
	string sentenceAnalyzed;
	char inputChar;
	int stringLength5;
	int totalVowels;
	int totalBlanks;
	int totalOthers;
	char ch;

	fout.open("ColeCEx1Output.txt");

//Problem 1
//Initialize setprecision
    cout << fixed << setprecision(2);
	fout << fixed << setprecision(2);
	//Output a divider on the screen
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//Static cast string length to college length and so forth
	stringLength1 = static_cast<int>(COLLEGE.length());
	stringLength2 = static_cast<int>(CST_PROGRAMMER.length());
	stringLength3 = static_cast<int>(CLASS_AND_LAB.length());
	//Static cast string length for snow fall amounts
	stringLength4 = static_cast<int>(SNOW_FALL_AMOUNTS.length());

	//Output header to screen
	cout << setw((WIDTH + stringLength1) / 2) << COLLEGE << endl;
	cout << setw((WIDTH + stringLength2) / 2) << CST_PROGRAMMER << endl;
	cout << setw((WIDTH + stringLength3) / 2) << CLASS_AND_LAB << endl;

	//Output a divider on the screen
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

//Problem 2

	//Output header to screen
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setw((WIDTH + stringLength1) / 2) << COLLEGE << endl;
	fout << setw((WIDTH + stringLength2) / 2) << CST_PROGRAMMER << endl;
	fout << setw((WIDTH + stringLength3) / 2) << CLASS_AND_LAB << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setfill(' ') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setw((WIDTH + stringLength4) / 2) << SNOW_FALL_AMOUNTS << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	cout << "Enter the number of days of snow: ";
	cin >> daysOfSnow;
	fout << "Number of days of snow is: " << daysOfSnow << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	
	//Prompt user to enter number of days of snow
	fout << "Day" << setw(23) << "Amount of Snow" << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	//Initialize total snowfall variable
	totalSnowFall = 0;
	//Needs to be zero b/c user hasnt entered anything (adds to zero to get a running total)
	//Initialize most snow and most snow days
	mostSnowDay = 0;
	mostSnow = 0;
	for (index = 1; index <= daysOfSnow; index++)
	{
		cout << "How much snow fell on day " << index << ":";
		cin >> snowfallAmount;
		fout << index << setw(20) << snowfallAmount << endl;
		totalSnowFall += snowfallAmount;
		if (snowfallAmount > mostSnow)
		{
			mostSnow = snowfallAmount;
			mostSnowDay = index;
		}
	}

	cout << setfill(' ') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//Continue making the divider
	fout << "Total:" << setw(15) << totalSnowFall << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//Determine day with most snow
	fout << "Day # " << mostSnowDay << " had the most snow, the amount is: " << mostSnow;

	//Problem 3

	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	cout << "Enter a sentence for statistical analysis, enter # to end sentence:" << endl;
	//cin >> sentenceAnalyzed;
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//Static cast string length for sentence analysis header
	stringLength5 = static_cast<int>(SENTENCE_ANALYSIS.length());

	fout << setfill(' ') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setfill(' ') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << setw((WIDTH + stringLength5) / 2) << SENTENCE_ANALYSIS << endl;
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	// Get input from the keyboard until a sentinel character is input
	cin.ignore(100, '\n');
	cin.get(inputChar);
	
	//Initialize totals
	totalVowels = 0;
	totalBlanks = 0;
	totalOthers = 0;
	//Make a sentinel while loop
	while (inputChar != SENTINEL)
	{
		// print the character to a file
		fout << inputChar;
		// get next character
		cin.get(inputChar);
		inputChar = static_cast<char>(toupper(inputChar));
		if (inputChar == 'A' || inputChar == 'E' || inputChar == 'I'
			|| inputChar == 'O' || inputChar == 'U')
		{
			totalVowels++;
		}
		else if (inputChar == ' ')
		{
			totalBlanks++;
		}
	
		
		else
		{
			totalOthers++;
		}
	}

	fout << endl;
	
	//Enter the data to the output file
	
	fout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
	fout << "The number of vowels: " << totalVowels << endl;
	fout << "The number of blanks: " << totalBlanks << endl;
	fout << "The number of others: " << totalOthers << endl;
	OutputHeading(fout);
	OutputHeading((ofstream&)cout);
	OutputDivider(fout);
	OutputDivider((ofstream&)cout);

	//Close output file
	fout.close();

	return 0;
}
//OutputDivider: This function will print 
//an additional divider line to the screen
void OutputDivider(ofstream& fout)
{
	fout << setfill('-')
		<< setw(WIDTH)
		<< '-' << setfill(' ') << endl;
}
//OutputHeading: This function will
//print a heading to the stream 
//passed in
void OutputHeading(ofstream& fout)
{
	OutputDivider(fout);

	fout << setw((CST_PROGRAMMER.length() + WIDTH) / 2)
		<< CST_PROGRAMMER << endl;
	OutputDivider(fout);
}
