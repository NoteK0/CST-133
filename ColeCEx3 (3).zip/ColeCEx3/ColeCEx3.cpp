//-----------------------------------------------------------------------------
//Exercise 3 Grading Block
//Name:  
//Grade:
//General Comments:
//  
//  
//  
//  
//Standard Requirements
//  Requirements met as specified in the CST Program Style Requirements 
//    document
//  Which includes but not limited to:
//    Program Creation
//    Documentation
//    File Requirements
//    Constants
//    Variables 
//    Code
//
//Comments:
//  
//Points Lost -------------------------------------------------------------> 
//
//General Function Specs:
//  Functions correctly named following course specifications
//  Functions prototypes correctly placed
//  Functions prototypes and definitions appear in the
//    ORDER listed below in the correct location
//  Function calls appropriately placed and used in program
//  Function definitions correctly placed
//  Documentation block above EACH function following course specifications
//    Functions blocked appropriately
//  Proper use of reference parameters
//  Proper use of value parameters 
//
//Program Specifications
//  Constant created for 
//    college name
//    student name 
//    exercise number
//    screen width
//    sentinel value '#'
//    number of judges
//
//  Heading for the exercise output to the output file 
//  Output file name changed to Ex3Out.txt
//
//Comments:
//  
//Points Lost -------------------------------------------------------------> 
//
//Exercise 3 General Functions
// Functions created for the following:
//   1.  Output the standard course heading to the output file
//   2.  Output a divider to the output file
//
//Problem 1 - Counting Odd and Even numbers
// Functions created for the following:
//   3.  Output the problem heading to the output file
//   4.  Initialize the counters and accumulators
//   5.  Check if a number that was read is even or odd, 
//       increment appropriate count
//   6.  Output the number and the two sums to the output file
//   7.  Output the even count and odd count to the output file
// 
// Specifications for this exercise:
//  Primer and a changer used for a file processing loop 
//  Output of Divider used to separate output as needed
//  Centered output headings
//  Column heading output to identify the data in the columns
//  All numbers read, one at a time, echo printed to output
//    file, aligned in the column
//
//Comments:
//    
//    
//      
//Points Lost -------------------------------------------------------------> 
//
//Problem 2 - Dancing with the Faculty
//  Functions created for:
//   8. Output the "Dancing with the Faculty" Heading to the output file
//   9. Output the contestant's number and name to the output file
//  10. Process 5 scores and return the total score and the lowest score
//  11. Calculate the final score
//  12. Output the final score to the output file
//  13. Check the newly calculated final score to determine 
//      if this is the winning score
//  14. Output the winner's name and the winning score to the output file 
//
// Specifications for this exercise:
//  Output of Divider used to separate output as needed
//  Centered output heading
//  Set formatting of floating point values to 1 decimal place
//  Winner name set to null string initially
//  Winning score set to -1 initially
//  Primer and a changer used for a file processing loop 
//  getline() used for input of name as a string
//  # of contestant calculated
//  name & # of contestant output to the output file
//  For loop used to read judges' scores
//  Only ONE variable used for the score
//  Output the score # and the score to the output file
//  Total score calculated correctly, dropping lowest score
//  Lowest score determined correctly based on the 5 scores
//  Lowest score set initially to an invalid data value
//  Final score for each contestant calculated correctly 
//    based on number of judges & output to the output file
//  Winner's name and final score determined and
//   output to the output file
//  Efficient testing used for this solution
//
//Comments:   
//
//  
//Points Lost -------------------------------------------------------------> 
//
//Total Possible Lab Grade ------------------------------------------------> 100
//Total Points Lost -------------------------------------------------------> 
//Actual Lab Grade --------------------------------------------------------> 

//-----------------------------------------------------------------------------
//Programmer's Name:  Chad Cole
//Program:  Exercise 3
//Program Description (IPO):
// The logical output file for ex3Out.txt is opened
// Problem #1:
//  Initialize the odd & even count, the odd & even sum
//  The logical input file for ex2Numbers.txt is opened
//  First number is read from the logical input file for ex2Numbers.txt
//  While numbers are in the logical input file for ex2Numbers.txt:
//    Determine if the number is odd or even
//     increment the appropriate count & add the value to either
//     the even or odd sum. (O is not added to either count or sum)
//    The number, the current even sum, the current odd sum are output to the
//     output file, ex2Out.txt
//    The even count & the odd count are output to the 
//     logical output file for ex2Out.txt
//  The logical input file for ex2Numbers.txt is closed  
// Create functions to replicate these tasks
//
//Problem #2 - Dancing with the Faculty 
//Initialize scores
// Initalize contestant names
// Initialize winning contestant and their name to preset values
// Grab data from scores.txt
// While data is being read...Initialize score number, total score, and lowest score
// Initialize a for loop with how many times it needs to repeat
// Increment score number and output it
// Determine if their score is the lowest score
// Determine the final score of the contestant
// Update if this score is the highest score and winning contestant
// Output contestant and their scores to output file
// Repeat until all contestants are output
// Output winning contestant and their score
// Create functions to replicate these tasks
//-----------------------------------------------------------------------------


#include <iostream> //Include input output stream


#include <fstream> //Include file stream


#include <iomanip> //Include input output manipulation


#include <string> //Include strings


using namespace std; //Use namespace

//Set constants

const string COLLEGE = "SUNY Broome Community College"; //Constants for Problem 1
const string CST_PROGRAMMER = "Chad Cole";
const string CLASS_AND_LAB = "CST 133 - Exercise 3";
const string EVEN_AND_ODD_COUNT = "Even and Odd Count";
const int NUMBER_OF_JUDGES = 5;
const int WIDTH = 80;
const char divider = '-';

const string DANCING_WITH_THE_FACULTY = "Dancing With the Faculty"; //Constants for Problem 2

void OutputHeading(ofstream& fout, int WIDTH, string COLLEGE, string CST_PROGRAMMER, string CLASS_AND_LAB); //Functions for Problem 1
//This is called the prototype. Needs to be defined before every function
void OutputDivider(ofstream& fout, int WIDTH, char divider);
void CountsOutputHeading(ofstream& fout, string EVEN_AND_ODD_COUNT, int WIDTH);
void EvenOddCountersAccumulators(int &evenCount, int &evenSum, int &oddCount, int &oddSum); 
void IncrementerUpdater(ofstream& fout, ifstream& fin, int value, int &evenCount, int &evenSum, int &oddCount, int &oddSum);
void SingleEvenOddOutput(ofstream& fout, int value, int evenCount, int oddCount);
void EvenSumOddSum(ofstream& fout, int oddSum, int evenSum);
void OutputHeading2(ofstream& fout, int WIDTH, string DANCING_WITH_THE_FACULTY); //Functions for Problem 2
void ContestantNameAndNumber(ofstream& fout, int& scoreNumber, double& totalScore, double& lowestScore, int contestantNumber, string name);
void ContestantScoreAndLowestScore(ofstream& fout, ifstream& fin2, int &index, double &score, int& scoreNumber, double& totalScore, double& lowestScore);
void FinalScoreCalculation(ofstream& fout, double &finalScore, double totalScore, double lowestScore, int NUMBER_OF_JUDGES);
void FinalScoreOutput(ofstream& fout, int WIDTH, double finalScore);
void WinningScoreCalculation(ofstream& fout, double &finalScore, double &highestScore, string &winningContestantName, string &name);
void WinningScoreOutput(ofstream& fout, string winningContestantName, double highestScore);

int main() {

    int stringLength1; //Variables for Problem 1
    int stringLength2;
    int stringLength3;
    int stringLength4;
    int stringLength5;
    int evenCount;
    int oddCount;
    int oddSum;
    int evenSum;
    int value;
    int index;

    ifstream fin;
    ifstream fin2;
    ofstream fout;


    string name; //Variables for Problem 2
    int contestantNumber;

    double score;
    int scoreNumber;

    double lowestScore;
    double totalScore;
    double finalScore;
    double highestScore;
    string winningContestantName;

    //Problem 1


    fin.open("Ex3Numbers.txt"); //Open input and output files
    fout.open("Ex3Out.txt");


    stringLength1 = static_cast<int>(COLLEGE.length()); //Static cast string length to college length and so forth
    stringLength2 = static_cast<int>(CST_PROGRAMMER.length());
    stringLength3 = static_cast<int>(CLASS_AND_LAB.length());
    stringLength4 = static_cast<int>(EVEN_AND_ODD_COUNT.length());
    stringLength5 = static_cast<int>(DANCING_WITH_THE_FACULTY.length());

   

    OutputHeading(fout, WIDTH, COLLEGE, CST_PROGRAMMER, CLASS_AND_LAB); //Call the OutputHeader function to the main
    OutputHeading((ofstream&)cout, WIDTH, COLLEGE, CST_PROGRAMMER, CLASS_AND_LAB);
    
    OutputDivider(fout, WIDTH, '-'); //Call the OutputDivider function to the main
    OutputDivider((ofstream&)cout, WIDTH, '-');

    CountsOutputHeading(fout, EVEN_AND_ODD_COUNT, WIDTH); //Call the CountsOutputHeading function to the main
    CountsOutputHeading((ofstream&)cout, EVEN_AND_ODD_COUNT, WIDTH);

    EvenOddCountersAccumulators(evenCount, evenSum, oddCount, oddSum); //Call the EvenOddCountersAccumulators function to the main
  
    while (fin >> value) //Loop through each number in the input file
    {
     

        IncrementerUpdater(fout, fin, value, evenCount, evenSum, oddCount, oddSum); //Call the IncrementerUpdater function to the main
        

        SingleEvenOddOutput(fout, value, evenCount, oddCount); //Call the SingleEvenOddOutput function to the main
        
       
        cout << endl; //Move to the next line in the console
        fout << endl; //Move to the next line in the output file

    }      

    EvenSumOddSum(fout, oddSum, evenSum); //Call the EvenSumOddSum function to the main

    fin.close(); //Close input file

    //Problem 2


    OutputHeading2(fout, WIDTH, DANCING_WITH_THE_FACULTY); //Call the OutputHeading2 function to the main
    OutputHeading2((ofstream&)cout, WIDTH, DANCING_WITH_THE_FACULTY);
    

    fin2.open("scores.txt"); //Open new input file


    contestantNumber = 1;  //Initialize contestant and winner variables outside of loop
    highestScore = -1;
    winningContestantName = "";

    getline(fin2, name, '#'); //Kickstart the loop by grabbing first contestant's name
    while (fin2)
    {

        ContestantNameAndNumber(fout, scoreNumber, totalScore, lowestScore, contestantNumber, name); //Call the ContestantNameAndNumber function to the main
        

        ContestantScoreAndLowestScore(fout, fin2, index, score, scoreNumber, totalScore, lowestScore); //Call the ContestantScoreAndLowestScore function to the main
        

        FinalScoreCalculation(fout, finalScore, totalScore, lowestScore, NUMBER_OF_JUDGES); //Call the FinalScoreCalculation function to the main
       
        FinalScoreOutput(fout, WIDTH, finalScore); //Call the FinalScoreOutput function to the main
        FinalScoreOutput((ofstream&)cout, WIDTH, finalScore);

        WinningScoreCalculation(fout, finalScore, highestScore, winningContestantName, name); //Call the WinningScoreCalculation function to the main
        

        fin2.ignore(100, '\n');
        getline(fin2, name, '#');

        contestantNumber++;
    }

    WinningScoreOutput(fout, winningContestantName, highestScore); //Call the WinningScoreOutput function to the main

    fin2.close(); //Close input and output files
    fout.close();
    return 0; //End program
}

//---------------------------------------------------------------------
//Function #1
//OutputHeading2 - This function prints the college name, exercise
//                number, and programmer name to the output file.
//---------------------------------------------------------------------
void OutputHeading(ofstream& fout, int WIDTH, string COLLEGE, string CST_PROGRAMMER, string CLASS_AND_LAB)
{
    
    
    OutputDivider(fout, WIDTH, '-');
    
    fout << setw((WIDTH + COLLEGE.length()) / 2) << COLLEGE << endl;
    fout << setw((WIDTH + CST_PROGRAMMER.length()) / 2) << CST_PROGRAMMER << endl;
    fout << setw((WIDTH + CLASS_AND_LAB.length()) / 2) << CLASS_AND_LAB << endl;
}

//---------------------------------------------------------------------
//Function #2
//OutputDivider - This function prints a divider to the output file.            
//---------------------------------------------------------------------
void OutputDivider(ofstream& fout, int WIDTH, char divider)
{
    fout << setfill(divider) << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;
    

}

//---------------------------------------------------------------------
//Function #3
//CountsOutputHeading - This function will print the Even and Odd 
//                      count heading along with a divider           
//---------------------------------------------------------------------
void CountsOutputHeading(ofstream& fout, string EVEN_AND_ODD_COUNT, int WIDTH)
{
    fout << setw((WIDTH + EVEN_AND_ODD_COUNT.length()) / 2) << EVEN_AND_ODD_COUNT << endl;
    OutputDivider(fout, WIDTH, '-');
    fout << setw(20) << "Number" << setw(25) << "Even Sum" << setw(25) << "Odd Sum" << endl;
}
//---------------------------------------------------------------------
//Function #4
//EvenOddCountersAccumulators - This function will initialize the   
//                              counters and accumulators for the
//                              even and odd numbers
//---------------------------------------------------------------------
void EvenOddCountersAccumulators(int &evenCount, int &evenSum, int &oddCount, int &oddSum)
{
    evenCount = 0;  
    evenSum = 0;
    oddCount = 0;
    oddSum = 0;
    
}
//---------------------------------------------------------------------
//Function #5
//IncrementerUpdater -          This function will check if a number was
//                              read from the input file, increment the
//                              even and odd counts, and update the sums
//---------------------------------------------------------------------
void IncrementerUpdater(ofstream& fout, ifstream& fin, int value, int &evenCount, int &evenSum, int &oddCount, int &oddSum)
{
        cout << setw(20) << value;  //Output the number to console
        fout << setw(20) << value;  //Output the number to output file
        if (value % 2 == 0) //Update evenSum and output to console and file
        {
            evenCount += value;
            evenSum++;

        }
        else //Update oddSum and output to console and file
        {
            oddCount += value;
            oddSum++;

        }
    
}
//---------------------------------------------------------------------
//Function #6
//SingleEvenOddOutput -          This function will output a single row
//                               of the value read in, the even count,
//                               and the odd count
//---------------------------------------------------------------------
void SingleEvenOddOutput(ofstream& fout, int value, int evenCount, int oddCount)
{
    cout << setw(25) << evenCount;
    fout << setw(25) << evenCount;
    cout << setw(25) << oddCount;
    fout << setw(25) << oddCount;
}
//---------------------------------------------------------------------
//Function #7
//EvenSumOddSum -                This function will output a single row
//                               of the even sum and odd sum
//                               
//---------------------------------------------------------------------
void EvenSumOddSum(ofstream& fout, int oddSum, int evenSum)
{
    cout << "The total count of even numbers is " << evenSum << " and the total count of odd numbers is "
         << oddSum << endl;
    fout << "The total count of even numbers is " << evenSum << " and the total count of odd numbers is "
        << oddSum << endl;
}
//---------------------------------------------------------------------
//Function #8
//OutputHeading2 - This function will print the heading for Problem 2              
//---------------------------------------------------------------------
void OutputHeading2(ofstream& fout, int WIDTH, string DANCING_WITH_THE_FACULTY)
{
    OutputDivider(fout, WIDTH, '-');
    fout << setw((WIDTH + DANCING_WITH_THE_FACULTY.length()) / 2) << DANCING_WITH_THE_FACULTY << endl;
    OutputDivider(fout, WIDTH, '-');
}
//---------------------------------------------------------------------
//Function #9
//ContestantNameAndNumber - This function will output the contestant's
//                          name and number 
//---------------------------------------------------------------------
void ContestantNameAndNumber(ofstream& fout, int &scoreNumber, double &totalScore, double &lowestScore, int contestantNumber, string name)
{
    fout << fixed << setprecision(1); //Set decimal place to 1
    scoreNumber = 1; //Set score number, total score, and lowest scores outside of for loop
    totalScore = 0;
    lowestScore = 11;


    cout << "Contestant # " << contestantNumber << " name: " << name << endl; //Heading for a contestant
    fout << "Contestant # " << contestantNumber << " name: " << name << endl;
}
//---------------------------------------------------------------------
//Function #10
//ContestantScoreAndLowestScore - This function will process the five
//                                scores of the contestant and returns
//                                the lowest and total score
//---------------------------------------------------------------------
void ContestantScoreAndLowestScore(ofstream& fout, ifstream& fin2, int &index, double &score, int &scoreNumber, double &totalScore, double &lowestScore)
{
    for (int index = 2; index <= 6; index++) //Set up LCV
    {
        fin2 >> score; //Grab score from scores.txt
        cout << "Score # " << scoreNumber << ":" << setw(10); //Output to console score number
        fout << "Score # " << scoreNumber << ":" << setw(10);
        scoreNumber++; //Increment score number
        cout << score << endl; //Output data from text file
        fout << score << endl;

        totalScore += score; //Total score is the sum of all scores
        if (score < lowestScore) //If score is lower than the lowest score...
        {
            lowestScore = score; //Update the lowest score
        }

    }

}
//---------------------------------------------------------------------
//Function #11
//FinalScoreCalculation         - This function will calculate the 
//                                final score of a contestant                             
//---------------------------------------------------------------------
void FinalScoreCalculation(ofstream& fout, double &finalScore, double totalScore, double lowestScore, int NUMBER_OF_JUDGES)
{
    finalScore = totalScore - lowestScore; //Contestant's final score is total score minus lowest score...
    cout << setprecision(2);
    fout << setprecision(2);
    finalScore /= (NUMBER_OF_JUDGES - 1); //Divided by 5 minus 1
}
//---------------------------------------------------------------------
//Function #12
//FinalScoreOutput              - This function will output the 
//                                final score of a contestant                             
//---------------------------------------------------------------------
void FinalScoreOutput(ofstream& fout, int WIDTH, double finalScore)
{
    OutputDivider(fout, WIDTH, '-');
    
    fout << "Final Score is: " << setw(4) << finalScore << endl;
    OutputDivider(fout, WIDTH, '-');
}
//---------------------------------------------------------------------
//Function #13
//WinningScoreCalculation       - This function will calculate the
//                                winning score                        
//---------------------------------------------------------------------
void WinningScoreCalculation(ofstream& fout, double &finalScore, double &highestScore, string &winningContestantName, string &name)
{
    if (finalScore > highestScore) //If the final score is greater than the highest score...
    {
        highestScore = finalScore; //Update the highest score
        winningContestantName = name; //Update the winning contestant's name
    }
}
//---------------------------------------------------------------------
//Function #14
//WinningScoreOutput            - This function will output the
//                                winning score                        
//---------------------------------------------------------------------
void WinningScoreOutput(ofstream& fout, string winningContestantName, double highestScore)
{
    cout << "The winning contestant is... " << winningContestantName << "! With a score of " //Output winning contestant and their score
        << highestScore << "!" << endl;
    fout << "The winning contestant is... " << winningContestantName << "! With a score of "
        << highestScore << "!" << endl;
}