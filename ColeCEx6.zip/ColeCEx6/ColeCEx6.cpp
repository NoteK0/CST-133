//-----------------------------------------------------------------------------
//Exercise 6 Grading Block
//Name:  
//Grade: 
//General Comments:
//  
//  
//  
//  
//Standard Requirements
//  Requirements met as specified in the CST Program Style Requirements 
//    document
//  Which includes but not limited to:
//    Program Creation
//    Documentation
//    File Requirements
//    Constants
//    Variables 
//    Code
//
//Comments:
//  
//  
//  
//Points Lost -------------------------------------------------------------> 
//
//General Function Specs:
//  Functions prototypes correctly placed
//  Functions correctly named following course specifications
//  Function calls appropriately placed and used in program
//  Function definitions correctly placed
//  Documentation above EACH function following course specifications
//  Functions prototypes and definitions appear in the
//    ORDER listed in the assignment in the correct location
//  Functions blocked appropriately
//Points will be deducted if necessary in the individual functions
//
//Program Specifications
//  Constants created for 
//    college name
//    student name 
//    course and exercise heading
//    screen width
//    array size
//
//  Heading for the exercise output to the output file 
//    EnrollReport.txt
//
//Comments:
//  
//Points Lost -------------------------------------------------------------> 
//
//Declarations
//  A string array of length 30
//  Four integer arrays of length 30
//
//Comment:
//  
//Points Lost -------------------------------------------------------------> 
//
//Files
//  Correct input file - Enroll.txt opened/closed in the main
//  Correct output file - EnrollReport.txt opened/closed in the main 
//
//Comment:
//
//Points Lost ------------------------------------------------------------->
//
//ReadData Function
//  Name, prototype, call, & definition correct
//  Parameter list correct
//  Correctly reads data into the parallel arrays, returns
//    the arrays and the tag field
//  Primer and changer used to read all data in the input file
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//CalculateEnrollmentChange Function
//  Name, prototype, call, & definition correct
//  Parameter list correct
//  Calculates the change for each program
//    storing result in the parallel array, enrollmentChange
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//CalculateTotalFunction
//  Name, prototype, call, & definition correct
//  Parameter list correct
//  Single return function
//  Correctly returns the total enrollment for ONE array ONLY
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//OutputEnrollmentData
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Calls the SetDivision() function
//  Correctly outputs the arrays in columned aligned output
//    with all data clearly labeled
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//SetDivision Function
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Single return function
//  Switch statement used to set a string to the division name
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//PositionOfHighest Function
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Correctly determines the highest position
//  Does not set highest to an arbitrary value
//  Does not check first value twice
//  Single return function
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//CalculateAverage Function
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Calculates the average of ONE array
//  Single return function
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//Output Functions
//OutputTotal, OutputAverage,OutputHighest, other
//  output functions as needed
//  Prototype, call and definitions for all
//  Functions named correctly
//  Parameter lists correct, sending string to reflect
//    which array is printing in functions necessary
//  Clearly labeled output sent to the output file
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//
//OutputDivider Function
//  Prototype and definition
//  Function copied from example
//  Function called appropriately
//  Clearly labeled output sent to the output file
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//Driver Main
//  Files opened 
//  Formatting for floating point set up 
//  Main is primarily calls to the functions
//  Functions called in the correct order (by tasks)
//  Functions called TWICE for each array where indicated
//  Files closed in the main
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//Output
//  One text file created with all output
//  Correct input used for the testing to create correct output
//  Output formatted and labeled appropriately
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//Miscellaneous
//  Errors not anticipated by your professor
//
//  Comment:
//    
//    
//Points lost -------------------------------------------------------------> 
//
//OutputDivisionEnrollment Function - BONUS
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct, division # passed in
//  CALLED three times to print each division
//
//  Comment:
//    
//    
//Points GAINED -----------------------------------------------------------> 
//
//OutputChangeReport Function - BONUS
//  Prototype, call and definition
//  Function named correctly
//  Parameter list correct
//  Clearly labeled output sent to the output file ordered
//    in ascending order of the change value
//  Code written efficiently
//
//  Comment:
//    
//    
//Points GAINED -----------------------------------------------------------> 
//
//Possible Points ---------------------------------------------------------> 200
//Total Points Lost ------------------------------------------------------->  
//Subtotal ----------------------------------------------------------------> 
//Bonus Points Gained ----------------------------------------------------->  
//Exercise Grade ----------------------------------------------------------> 
//-----------------------------------------------------------------------------
//Programmer's Name: Chad Cole
//Program:  Exercise 6
//Program Flow (IPO):
// No inputs from the user
// Configure functions for a divider and a heading
// Function to read data from a file and save it as different variables
// Function to calculate a difference between two numbers (enrollment)
// Function to calculate total number of values in an array
// Function to output enrollment data from arrays to an output file
// Function to assign divisions based off of code numbers
// Function to determine position of highest value in an array
// Function to calculate average enrollment of students across 25 majors
// Functions to output total, averages, and position of highest values in
// arrays as well as division and departments
// BONUS function to output statistics from each department specifically
//-----------------------------------------------------------------------------

#include <iostream> //Include input output stream

#include <fstream> //Include file stream


#include <iomanip> //Include input output manipulation


#include <string> //Include strings


using namespace std; //Use namespace

//Set constants
const string COLLEGE = "SUNY Broome Community College"; //Constants for Problem 1
const string CST_PROGRAMMER = "Chad Cole";
const string CLASS_AND_LAB = "CST 133 - Exercise 6";
const int WIDTH = 120;
const int MAX_INPUTS = 30; // Character limit for input lines read in
const char DIVIDER = '-';

void OutputDivider(ofstream& fout);	// Functions for Problem 1
void OutputHeading(ofstream& fout);
void ReadData(ifstream& fin, int lastYearEnrollment[], int thisYearEnrollment[], int divisionCode[], string program[], int& length);
void OutputEnrollmentData(ofstream& fout, int lastYearEnrollment[], int thisYearEnrollment[], int divisionCode[], string program[], int enrollmentChange[], int& length);
void CalculateEnrollmentChange(int lastYearEnrollment[], int thisYearEnrollment[], int enrollmentChange[], int length);
void CalculateTotal(int lastYearEnrollment[], int length, int& lastYearTotalEnrollment);
string SetDivision(int divisionCode[], int length, int index);
void OutputDivisionEnrollment(ofstream& fout, int lastYearEnrollment[], int thisYearEnrollment[], int divisionCode[], string program[], int enrollmentChange[], int& length, int divisionNumber);
int PositionOfHighest(int lastYearEnrollment[], int length);
double CalculateAverage(int lastYearEnrollment[], int length);
void OutputTotal(ofstream& fout, int lastYearTotalEnrollment, string whichTotal);
void OutputAverage(ofstream& fout, double averageCalculated, string whichAverage);
void OutputHighest(ofstream& fout, int highestPosition, int whichValue, string whichDivision, string whichDepartment, string whichArray);

int main(void)
{
	int stringLength1; //Variables for Problem 1
	int stringLength2;
	int stringLength3;
	int lastYearEnrollment[MAX_INPUTS];
	int thisYearEnrollment[MAX_INPUTS];
	int divisionCode[MAX_INPUTS];
	int enrollmentChange[MAX_INPUTS];
	int length = 0;
	int lastYearTotalEnrollment = 0;
	int thisYearTotalEnrollment = 0;
	int highestPosition = 0;
	double averageCalculated = 0;

	string program[MAX_INPUTS];

	ifstream fin;
	ofstream fout;

	stringLength1 = static_cast<int>(COLLEGE.length()); //Static cast string length to college length and so forth
	stringLength2 = static_cast<int>(CST_PROGRAMMER.length());
	stringLength3 = static_cast<int>(CLASS_AND_LAB.length());

	fin.open("Enroll.txt");		   // Open the input file
	fout.open("EnrollReport.txt"); // Open the output file

	fout << fixed << setprecision(3); // Set decimal points to three values

	OutputHeading(fout); // Call OutputHeading function to the main
	ReadData(fin, lastYearEnrollment, thisYearEnrollment, divisionCode, program, length); // Call ReadData function to the main
	CalculateEnrollmentChange(lastYearEnrollment, thisYearEnrollment, enrollmentChange, length); // Call CalculateEnrollmentChange function to the main
	CalculateTotal(lastYearEnrollment, length, lastYearTotalEnrollment); // Call CalculateTotal function to the main for last year
	CalculateTotal(thisYearEnrollment, length, thisYearTotalEnrollment); // Call CalculateTotal function to the main for this year
	OutputEnrollmentData(fout, lastYearEnrollment, thisYearEnrollment, divisionCode, program, enrollmentChange, length); // Call OutputEnrollmentData function to the main
	OutputTotal(fout, lastYearTotalEnrollment, "The total enrollment for last year was: "); // Call OutputTotal function to the main for last year
	OutputTotal(fout, thisYearTotalEnrollment, "The total enrollment for this year is: ");  // Call OutputTotal function to the main for this year
	highestPosition = PositionOfHighest(lastYearEnrollment, length); // Call PositionOfHighest function to the main for last year
	OutputHighest(fout, highestPosition, lastYearEnrollment[highestPosition], "Health", "Nursing", "last year");  // Call OutputHighest function to the main for last year
	//Parallel arrays are arrays called to by the same array index throughout multiple function calls 
	//(The idea is that highestPosition accesses the parallel arrays for the data)
	highestPosition = PositionOfHighest(thisYearEnrollment, length); // Call PositionOfHighest function to the main for this year
	OutputHighest(fout, highestPosition, thisYearEnrollment[highestPosition], "Technology", "Liberal Arts AS", "this year"); // Call OutputHighest to the main for this year
	averageCalculated = CalculateAverage(lastYearEnrollment, length); // Call CalculateAverage function to the main. Set your variable equal to function call to update it
	OutputAverage(fout, averageCalculated, "Last year's average enrollment was: "); // Call OutputAverage to the main for last year
	averageCalculated = CalculateAverage(thisYearEnrollment, length); // Call CalculateAverage function to the main for this year
	OutputAverage(fout, averageCalculated, "This year's average enrollment is: "); // Call OutputAverage to the main for this year
	OutputDivisionEnrollment(fout, lastYearEnrollment, thisYearEnrollment, divisionCode, program, enrollmentChange, length, 1); // Call OutputDivisionEnrollment for program 1
	OutputDivisionEnrollment(fout, lastYearEnrollment, thisYearEnrollment, divisionCode, program, enrollmentChange, length, 2); // Call OutputDivisionEnrollment for program 2
	OutputDivisionEnrollment(fout, lastYearEnrollment, thisYearEnrollment, divisionCode, program, enrollmentChange, length, 3); // Call OutputDivisionEnrollment for program 3

	fin.close(); // Close the input file
	fout.close(); // Close the output file

	return 0; // End program. If you see this once again hi Ms. Sedelmeyer
}
//---------------------------------------------------------------------
//Function #1
//OutputDivider - This function prints a divider to the output file.            
//---------------------------------------------------------------------
void OutputDivider(ofstream& fout)
{
	fout << setfill(DIVIDER) << setw(WIDTH + 1) << ' ' << setfill(' ') << endl; //Sets a divider as a callable function


}
//---------------------------------------------------------------------
//Function #3
//OutputHeading - This function prints the college name, exercise
//                number, and programmer name to the output file.
//---------------------------------------------------------------------
void OutputHeading(ofstream& fout)
{
	OutputDivider(fout); // Call OutputDivider 

	fout << setw((WIDTH + COLLEGE.length()) / 2) << COLLEGE << endl;	// Print Lab header to output file
	fout << setw((WIDTH + CST_PROGRAMMER.length()) / 2) << CST_PROGRAMMER << endl; // Do the same for rest of header
	fout << setw((WIDTH + CLASS_AND_LAB.length()) / 2) << CLASS_AND_LAB << endl;
	OutputDivider(fout); // Call OutputDivider 

}
//---------------------------------------------------------------------
//Function #4
//ReadData	    - This function reads the data from the input file
//				  into the four parallel arrays          
//---------------------------------------------------------------------
void ReadData(ifstream& fin, int lastYearEnrollment[], int thisYearEnrollment[], int divisionCode[], string program[], int& length)
{
	int intRead; // Intermediate variable to temporarily store integers read in
	int index; // Our counter

		for (index = 0; index < MAX_INPUTS && fin; index++) // When the iteration of the loop is less than the 25th and data is being read in, keep cycling through
		{
			 fin >> intRead; // Read in the first integer and save as intRead
			 lastYearEnrollment[index] = intRead; // The element at this iteration of lastYearEnrollment in the loop is intRead
			 fin.ignore(1); // Ignore 1 character
			 fin >> intRead; // Read in the next integer
			 thisYearEnrollment[index] = intRead; // The element at this iteration of thisYearEnrollment in the loop is intRead
			 fin.ignore(1); // Ignore 1 character
			 fin >> intRead; // Read in the next integer
			 divisionCode[index] = intRead; // The element at this iteration of divisionCode in the loop is intRead
			 getline(fin, program[index]); // The element at this iteration of program in the loop is stored as a string
			 length++; // Accumulate our tag field
		}
}
//---------------------------------------------------------------------
//Function #5
//CalculateEnrollmentChange - This function calculates the difference 
// between this year's enrollment number and last year's enrollment
// number and stores the results in the parallel array enrollmentChange.						  
//---------------------------------------------------------------------
void CalculateEnrollmentChange(int lastYearEnrollment[], int thisYearEnrollment[], int enrollmentChange[], int length)
{
	int index; // Our counter

	for (index = 0; index < length; index++) // While index is less than our tag field, increment the loop iteration
	{
		enrollmentChange[index] = thisYearEnrollment[index] - lastYearEnrollment[index]; // EnrollmentChange keeps track of difference in enrollments
	}
}
//---------------------------------------------------------------------
//Function #6
//CalculateTotal - This function calculate the total of the elements of
//				   any integer array                 
//---------------------------------------------------------------------
void CalculateTotal(int lastYearEnrollment[], int length, int& lastYearTotalEnrollment)
{
	int index; // Our counter

	for (index = 0; index < length; index++) // While index is less than our tag field, increment the loop iteration
	{
		lastYearTotalEnrollment += lastYearEnrollment[index];
	}
}
//---------------------------------------------------------------------
//Function #7
//OutputEnrollmentData - This function outputs to the output file, the
// degree�s program name, the program�s academic division,
// last year's enrollment number, this year's enrollment number, and the 
// enrollment change amount					 
//---------------------------------------------------------------------
void OutputEnrollmentData(ofstream& fout, int lastYearEnrollment[], int thisYearEnrollment[], int divisionCode[], string program[], int enrollmentChange[], int& length)
{
	int index; // Calling a locally defined variable from another function inside of another function saves the value
	fout << "Program" << setw(53) << "Division" << setw(22) << "Last Year" << setw(15) << "This Year" << setw(15) << "Change" << endl; // Configure output
	fout << setw(83) << "Enrollment" << setw(15) << "Enrollment" << endl;
	OutputDivider(fout);
	for (index = 0; index < length; index++) // While index is less than our tag field, increment the loop iteration
	{
		fout << left << setw(35) << program[index] << right << setw(25) << SetDivision(divisionCode, length, index) << setw(20) << lastYearEnrollment[index] 
			 << setw(15) << thisYearEnrollment[index] // Call every element during every loop iteration
			 << setw(15) << enrollmentChange[index] << endl; 
	}	 
}
//---------------------------------------------------------------------
//Function #8
//SetDivision   - This function assigns a string based on the division
//				  code                
//---------------------------------------------------------------------
string SetDivision(int divisionCode[], int length, int index)
{
	string divisionClass; // Variable to store division class
	int divisionNumber; // Intermediate variable to store our division codes
	
	
		divisionNumber = divisionCode[index]; // DivisionNumber is either a 1, 2, or 3

		switch (divisionNumber) { // Switch the output depending on the value in divisionNumber

		case 1:
			divisionClass = "Technology";
			break;
		case 2:
			divisionClass = "Business";
			break;
		case 3:
			divisionClass = "Health";
			break;
		}
	
	
	return divisionClass; // Return the edited variable for calling in the main
}
//---------------------------------------------------------------------
//Function #9
//PositionOfHighest - This function determines the position of the
// highest value in an integer array and returns the position					  
//---------------------------------------------------------------------
int PositionOfHighest(int lastYearEnrollment[], int length)
{
	int index; // Our counter
	int highestPosition = lastYearEnrollment[0]; // Set our default value to first element in array for later comparison
	for (index = 1; index < length; index++) // While index is less than our tag field, increment the loop iteration
	{
		if (lastYearEnrollment[index] > lastYearEnrollment[highestPosition]) // If the enrollment at x loop iteration is greater than x value of highestPosition
		{
			highestPosition = index; // highestPosition becomes index
		}
	}
	return highestPosition; // Return highestPosition
}
//---------------------------------------------------------------------
//Function #10
//CalculateAverage - This function determine the average number of
//					 students for all programs in one year					 
//---------------------------------------------------------------------
double CalculateAverage(int lastYearEnrollment[], int length) // You could also just pass in lastYearTotalEnrollment for both function calls
{
	double averageCalculated; // Our variable we are editing
	int sumOfEnrollment = 0; // Initialize sumOfEnrollment
	int index; // Our counter
	for (index = 0; index < length; index++) // While index is less than our tag field, increment the loop iteration
	{
		sumOfEnrollment += lastYearEnrollment[index]; // sumOfEnrollment accumulates off of lastYearEnrollment
	}
	averageCalculated = sumOfEnrollment / length; // Average is sum of values divided by number of values
	return averageCalculated; // Return to be called later
	
}
//---------------------------------------------------------------------
//Function #11
//OutputTotal - This function outputs the integer total with a label
//			    identifying which array is represented by this total					                   
//---------------------------------------------------------------------
void OutputTotal(ofstream& fout, int lastYearTotalEnrollment, string whichTotal) // If you wanted to set it to a specific width for each function call,
{																			     // send in the width you want to change during setw(width1)
	OutputDivider(fout);
	fout << whichTotal << lastYearTotalEnrollment << endl; // Output x enrollment
}
//---------------------------------------------------------------------
//Function #12
//OutputAverage - This function outputs the averages calculated 
//				  throughout the program
//---------------------------------------------------------------------
void OutputAverage(ofstream& fout, double averageCalculated, string whichAverage)
{
	OutputDivider(fout);
	fout << whichAverage << averageCalculated << endl; // Output x average array and x average calculated
	
}
//---------------------------------------------------------------------
//Function #13
//OutputHighest - This function outputs the position of the highest
// enrollment found in an array, the highest enrollment amount, the
// department, and the division (the name of the division).
//                
//---------------------------------------------------------------------
void OutputHighest(ofstream& fout, int highestPosition, int whichValue, string whichDivision, string whichDepartment, string whichArray)
{
	OutputDivider(fout);
	fout << "The position of the highest value for " << whichArray << " is: " << highestPosition << endl; // Congfigure the output
	fout << "Division: " << whichDivision << setw(15) << " Department: " << whichDepartment << endl;
	fout << "The highest value for " << whichArray << " is: " << whichValue << endl;
}
//-------------------------------BONUS---------------------------------
//---------------------------------------------------------------------
//Function #14
//OutputDivisionEnrollment - This function prints division data and 
//							 headers representing it							 
//---------------------------------------------------------------------
void OutputDivisionEnrollment(ofstream& fout, int lastYearEnrollment[], int thisYearEnrollment[], int divisionCode[], string program[], int enrollmentChange[], int& length, int divisionNumber)
{
	string divisionClass;
	OutputDivider(fout);
	switch (divisionNumber) { // divisionNumber determines which data we will be presenting

	case 1:
		divisionClass = "Technology";
		fout << setw(62) << " The following data is from the " << divisionClass << " division" << endl; // You can replace function calls within functions
		break;
	case 2:
		divisionClass = "Business";
		fout << setw(64) << " The following data is from the " << divisionClass << " division" << endl; // You can replace function calls within functions
		break;
	case 3:
		divisionClass = "Health";
		fout << setw(66) << " The following data is from the " << divisionClass << " division" << endl; // You can replace function calls within functions
		break;
	}

	OutputDivider(fout);
	int index; // Calling a locally defined variable from another function inside of another function saves the value
	fout << "Program" << setw(55) << "Last Year" << setw(15) << "This Year" << setw(15) << "Change" << endl; // Configure output
	fout << setw(63) << "Enrollment" << setw(15) << "Enrollment" << endl;
	OutputDivider(fout);
	

	
	for (index = 0; index < length; index++) // While index is less than our tag field, increment the loop iteration
	{
		if (divisionCode[index] == divisionNumber) // If divisionCode at x iteration is equal to a 1, 2, or 3 respectively
		{
			fout << left << setw(35) << program[index] << right << setw(25) << lastYearEnrollment[index] // Output to the output file said data
				<< setw(15) << thisYearEnrollment[index]
				<< setw(15) << enrollmentChange[index] << endl;
		}
		
	}
}
////--------------------------------------------------------------------- 
////Function #15
////OutputChangeReport - This function outputs the change values in order
////					   from the ascending order of the change value				   
////---------------------------------------------------------------------
//void OutputChangeReport(ofstream& fout, int lastYearEnrollment[], int thisYearEnrollment[], int divisionCode[], string program[], int enrollmentChange[], int& length)
//{
//	int index; // Calling a locally defined variable from another function inside of another function saves the value
//	fout << "Program" << setw(55) << "Division" << setw(20) << "Last Year" << setw(15) << "This Year" << setw(15) << "Change" << endl;
//	fout << setw(83) << "Enrollment" << setw(15) << "Enrollment" << endl;
//	OutputDivider(fout);
//	for (index = 0; index < length; index++)
//	{
//		
//	}
//}