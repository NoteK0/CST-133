/* -------------------------------------------------------------------------------------------------------------------
Programmer's Name: Chad Cole
Program: Practice
Grade:
Comments:


-----------------------------------------------------------------------------------------------------------------------
*/
/* -------------------------------------------------------------------------------------------------------------------
Programmer Name:     Chad Cole
Program: Practice
Program Flow (IPO):
Output a heading to the screen
Output a menu of shape options to the screen
Input a number corresponding to a shape type from the keyboard
Determine the shape number entered based on the shape choice entered
	Input the dimension of the shape from the keyboard
	Calculate the area of the shape 
	Output the shape type, dimensions, and the area to the screen
	Output an error message to the screen if not valid
----------------------------------------------------------------------------------------------------------------------

*/

//For input and output on the screen
#include <iostream>

//For formatting of the output
#include <iomanip>

//To use the string data type
#include <string>

using namespace std;

const string COLLEGE = "SUNY Broome Community College";
const string MY_NAME = "Chad Cole";

//Value of PI for area calculations
const double PI = 3.141592;

//Width of screen for divider
const int WIDTH = 60;

int main(void)
{
	int shapeChoice;

	double radius;
	double length;
	double width;
	double height;
	double area;

	string shapeName;

	//Set up formatting of fixed decimal values for the output to the screen
	cout << fixed << setprecision(2);

	//Output a divider on the screen
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//Output the programmer's name & college to the screen
	cout << COLLEGE << endl;
	cout << MY_NAME << endl;
	cout << "Output from the Practice" << endl;

	//Output a divider on the screen
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//Output a menu for the user selection to the screen
	cout << "Shape Area Selection" << endl;
	cout << "1. Rectangle" << endl;
	cout << "2. Circle" << endl;
	cout << "3. Cylinder" << endl;

	//Output a divider on the screen
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//Input the user's choice for shape from the keyboard
	cout << "Enter shape choice (1, 2, or 3): ";
	cin >> shapeChoice;

	//Output a divider on the screen
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//User entered 1 for a rectangle
	if (shapeChoice == 1)
	{//choice 1

		//Assign the shape name
		shapeName = "Rectangle";

		//Input the dimensions of the rectangle from the keyboard
		cout << "Enter the length and width of the " << shapeName << " separated by a space: ";
		cin >> length >> width;

		//Calculate the area of the shape
		area = length * width;

		//Output the shape name, dimensions, and area to the screen
		cout << "For the shape: " << shapeName << endl;
		cout << "Length: " << left << setw(12) << length << right
			 << setw(12) << "Width: " << width << endl;
		cout << "Area is: " << setw(12) << area << endl;

	}//end choice 1

	//User entered 2 for a circle
	else if (shapeChoice == 2)
	{//choice 2

		//Assign the shape name
		shapeName = "Circle";

		//Input the dimensions of the circle from the keyboard
		cout << "Enter the radius of the " << shapeName << " : ";
		cin >> radius;

		//Calculate the area of the shape
		area = PI * radius * radius;

		//Output the shape name, dimensions, and area to the screen
		cout << "For the shape: " << shapeName << endl;
		cout << "Radius: " << setw(8) << radius << endl;
		cout << "Area is: " << setw(8) << area << endl;

	}//end choice 2

	//User entered a 3 for a cylinder 
	else if (shapeChoice == 3)
	{//choice 3

		//Assign the shape name
		shapeName = "Cylinder";

		//Input the dimensions of the cylinder from the user
		cout << "Enter the radius and height of the " << shapeName << " separated by a space: ";
		cin >> radius >> height;

		//Calculate the area of the shape
		area = 2 * (PI * radius * radius) + 2 * PI * radius * height;

		//Output the shape name, dimensions, and area to the screen
		cout << "For the shape: " << shapeName << endl;
		cout << "Radius: " << left << setw(12) << radius
			 << right << setw(12) << "Height: " << height << endl;
		cout << "Area is: " << setw(12) << area << endl;

	}//end choice 3

	//Choice was not 1, 2, or 3
	else
	{//default error message

		//Output a divider on the screen
		cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

		//Output the error message to the screen
		cout << "Invalid shape choice entered, no calculations performed" << endl;
		cout << "Please run the program again and select 1, 2, or 3" << endl;

	}

	//Output a divider on the screen
	cout << setfill('-') << setw(WIDTH + 1) << ' ' << setfill(' ') << endl;

	//End the program, return control to OS
	return 0;
}